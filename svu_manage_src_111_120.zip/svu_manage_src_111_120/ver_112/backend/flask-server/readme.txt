1. install venv
https://gist.github.com/Geoyi/d9fab4f609e9f75941946be45000632b
> sudo apt-get install python3-pip
> sudo pip3 install virtualenv
> virtual venv

2. go to backend directory:
> cd ~/work/svu_manage/backend/flask-server 
> source venv/bin/activate
> python3 server.py
>> http://127.0.0.1:5000

3. go to frontend directory:
start the chrome browser
> cd ~/work/svu_manage/frontend
> npm install (if node_modules is missing)
> npm start
