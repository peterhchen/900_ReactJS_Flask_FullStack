import { useState } from 'react'
import CourseList from './CourseList'
const Transcript = () => {
    const [courses, setCourses] = useState([
        {page: "All Courses", trimester: "2015 Fall Trimester", course_no: "CE450", 
            title: "Computer Architecture I", credit_attempted: 3,
            credit_earned: 3, grade:"C", points: 6.00, id: 1},
        {page: "All Courses", trimester: "2015 Fall Trimester", course_no: "CS440", 
            title: "Computer Networks I", credit_attempted: 3,
            credit_earned: 3, grade:"B-", points: 8.10, id: 2},
        {page: "All Courses", trimester: "2015 Fall Trimester", course_no: "CS440", 
            title: "Computer Networks I", credit_attempted: 3,
            credit_earned: 3, grade:"B-", points: 8.10, id: 3},
        {page: "All Courses", trimester: "2016 Spring Trimester", course_no: "CS500", 
            title: "Operating System Design", credit_attempted: 3,
            credit_earned: 3, grade:"B+", points: 9.90, id: 4},
        {page: "All Courses", trimester: "2016 Spring Trimester", course_no: "CS520", 
            title: "Database System Principle", credit_attempted: 3,
            credit_earned: 3, grade:"B+", points: 9.90, id: 5},
        {page: "All Courses", trimester: "2016 Spring Trimester", course_no: "CS596-026", 
            title: "SP: OpenStack Cloud Architecture", credit_attempted: 3,
            credit_earned: 3, grade:"B", points: 9.00, id: 6},
        {page: "All Courses", trimester: "2016 Summer Trimester", course_no: "CS540", 
            title: "Computer Network II", credit_attempted: 3,
            credit_earned: 3, grade:"B-", points: 8.10, id: 7},
        {page: "All Courses", trimester: "2016 Summer Trimester", course_no: "CS596-027", 
            title: "SP: Software Defined Networking", credit_attempted: 3,
            credit_earned: 3, grade:"A", points: 12.00, id: 8},
        {page: "All Courses", trimester: "2016 Summer Trimester", course_no: "CS596-039", 
            title: "SP: Web Applicaiton Testing", credit_attempted: 3,
            credit_earned: 3, grade:"A+", points: 12.90, id: 9},
        {page: "All Courses", trimester: "2016 Fall Trimester", course_no: "CS502", 
            title: "Design and Analysis of Algorithms", credit_attempted: 3,
            credit_earned: 3, grade:"B-", points: 8.10, id: 10},
        {page: "All Courses", trimester: "2016 Fall Trimester", course_no: "CS596-028", 
            title: "SP: Hadoop and Big Data", credit_attempted: 3,
            credit_earned: 3, grade:"A+", points: 12.90, id: 11},
        {page: "All Courses", trimester: "2016 Fall Trimester", course_no: "CS596-041", 
            title: "SP: High Performance Networks", credit_attempted: 3,
            credit_earned: 3, grade:"B+", points: 9.90, id: 12},
        {page: "All Courses", trimester: "2015 Transfer", course_no: "EE220", 
            title: "RFIC Design I", credit_attempted: "TR",
            credit_earned: 3, grade:"TR", points: "TR", id: 13},
        {page: "All Courses", trimester: "2015 Transfer", course_id: "EE250", 
            title: "Prob Ran Vari & St P", credit_attempted: "TR",
            credit_earned: 3, grade:"TR", points: "TR", id: 14},
        {page: "All Courses", trimester: "2015 Transfer", course_id: "EE223", 
            title: "Analog Int Ckt", credit_attempted: "TR",
            credit_earned: 3, grade:"TR", points: "TR", id: 15}
    ]);
    const handleCreate = () => {
    }
    const handleFind = (param, e) => {
        console.log('handle ' + param, e.target);
    }
    const handleSave = (param, e) => {
        console.log('handle ' + param, e.target);
    }
    const handleDel = (param, e) => {
        console.log('handle ' + param, e.target);
    }
    return (
        <div className = "home">
            <h2>Transcript Page</h2>
            <CourseList courses = { courses } title = {"SVU courses"} />
            <button onClick={ handleCreate }>Create</button>
            <button onClick={(e) => handleFind ('Find', e)}>Find</button>
            <button onClick={(e) => handleSave ('Save', e)}>Save</button>
            <button onClick={(e) => handleDel ('Delete', e)}>Delete</button>
        </div>
    );
}
 
export default Transcript;