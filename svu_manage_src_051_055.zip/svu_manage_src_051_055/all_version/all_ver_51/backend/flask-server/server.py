from flask import Flask
app = Flask (__name__)

# API Route
@app.route ("/transcripts")
def transcripts():
    return {
        "kw": "1503011365; SOHAN BHARGAV KEESARA; 03-05-1993",
        "ID": "1503011365", 
        "Name": "SOHAN BHARGAV KEESARA",
        "DOB": "03-05-2993",
        "transcripts": [
        {
            "trimester": "2015 Transfer", "course_no": "EE220", "title": "RFIC Design I",
            "credit_attempted": "TR", "credit_earned": 3, "grade": "TR", "points": "TR",
            "tid": 1
        },
        {
            "trimester": "2015 Transfer", "course_id": "EE250", "title": "Prob Ran Vari & St P",
            "credit_attempted": "TR", "credit_earned": 3, "grade": "TR", "points": "TR",
            "tid": 2
        }]
    }

if __name__ == "__main__":
    app.run(debug = True)