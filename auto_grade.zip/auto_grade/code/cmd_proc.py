"""
Description:
    module cmd_proc for command processing
    12/22/2022 Created by Peter Hanping Chen
"""
import sys
class CmdProc ():
    """
    Description:
    Command Process
    """
    def __init__(self):
        self.reg_fn = ''

    @staticmethod
    def cmd_proc(argv):
        """
        Command Process of user input
        """
        #print('len(argv):', len(argv))
        reg_fn = ''
        c_dir = ''
        for i in range (1, len(argv)):  # ignire argv[0] = "python3"
            if "reg_fn" in argv[i]:
                reg_fn = argv[i+2].strip()
            if "c_dir" in argv[i]:
                c_dir= argv[i+2].strip()
        if reg_fn == "":
            print("Registeration file name (reg_fn) cannot be empty")
            sys.exit(1)
        if c_dir == "":
            print("Course dictory (c_dir) cannot be empty")
            sys.exit(1)
        return reg_fn, c_dir

    def __str__(self):
        return f'reg_fn: {self.reg_fn}'

    def __repr__(self):
        return f'reg_fn: {self.reg_fn}'
