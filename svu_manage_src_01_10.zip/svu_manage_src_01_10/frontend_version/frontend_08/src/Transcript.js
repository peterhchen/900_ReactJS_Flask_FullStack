import { useState } from 'react'
const Transcript = () => {
    //let id = "", name = "", degree = "", major = "", birthday = "", admDate = "";
    //let graduated = "";
    const [id, setId] = useState(""), [name, setName] = useState("");
    const [degree, setDegree] = useState(""), [major, setMajor] = useState("");
    const [birthday, setBirthday] = useState("");
    const [admDate, setAdmDate] = useState("");
    const [graduated, setGraduated] = useState("");
    const handleCreate = () => {
        /* id = "1503011365"; name = "SOHAN BHAGRAV KEESARA";
        degree = "MASTER OF COMPUTER SCIENCE"; major = "COMPUTER SCIENCE";
        birthday = "03-05-1993"; admDate = "Fall, 2015";
        graduated = "Fall, 2016"; */
        console.log('handle Create: '); console.log(' id: ' + id);
        console.log (' name: '+ name); console.log (' degree: ' + degree);
        console.log (' major: ' + major); console.log (' birthday: ', birthday);
        console.log (' admDate: ' + admDate); 
        console.log (' graduated: ', graduated);
        setId("1503011365"); setName("SOHAN BHAGRAV KEESARA");
        setDegree("MASTER OF COMPUTER SCIENCE"); setMajor("COMPUTER SCIENCE");
        setBirthday("03-05-1993"); setAdmDate("Fall, 2015");
        setGraduated("Fall, 2016");
    }
    const handleFind = (param, e) => {
        console.log('handle ' + param, e.target);
    }
    const handleSave = (param, e) => {
        console.log('handle ' + param, e.target);
    }
    const handleDel = (param, e) => {
        console.log('handle ' + param, e.target);
    }
    return (
        <div className = "home">
            <h2>Transcript Page</h2>
            <p>ID &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; { id } </p> 
            <p>NAME &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; { name } </p> 
            <p>DEGREE &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; { degree }</p>
            <p>MAJOR &emsp; &emsp; &emsp; &emsp; &emsp; &emsp;            { major }</p>
            <p>BIRTHDAY &emsp; &emsp; &emsp; &emsp; &emsp; &emsp;         { birthday }</p>
            <p>DATE OF ADMISSION &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; { admDate }</p>
            <p> GRADUDATED &emsp; &emsp; &emsp; &emsp; &emsp; &emsp;      { graduated }</p>
            <button onClick={ handleCreate }>Create</button>
            <button onClick={(e) => handleFind ('Find', e)}>Find</button>
            <button onClick={(e) => handleSave ('Save', e)}>Save</button>
            <button onClick={(e) => handleDel ('Delete', e)}>Delete</button>
        </div>
    );
}
 
export default Transcript;