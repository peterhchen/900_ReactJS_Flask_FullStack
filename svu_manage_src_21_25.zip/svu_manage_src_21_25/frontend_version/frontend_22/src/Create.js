const Create = () => {
    return (  
        <div className="create">
            <h2>Add a New Course</h2>
        </div>
    );
}
 
export default Create;