from flask import Flask
app = Flask (__name__)
@app.route ("/transcripts")
def transcripts():
    return {
        "transcripts": [
        {
            "trimester": "2015 Transfer", "course_no": "EE220", "title": "RFIC Design I",
            "credit_attempted": "TR", "credit_earned": 3, "grade": "TR", "points": "TR",
            "tid": 1
        },
        {
            "trimester": "2015 Transfer", "course_id": "EE250", "title": "Prob Ran Vari & St P",
            "credit_attempted": "TR", "credit_earned": 3, "grade": "TR", "points": "TR",
            "tid": 2
        }]
    }

@app.route ("/courses")
def courses():
    return {
        "courses": [
        {
            "trimester": "Fall, 2025", "course_no": "EE600", "title": "Data Science",
            "credit": 3, "instruictor": "Simon Au", 
            "cid": 1
        },
        {
            "trimester": "Fall, 2025", "course_no": "EE700", "title": "Machine Learning",
            "credit": 3, "instruictor": "Peter H. Chen",
            "cid": 2
        }]
    }

if __name__ == "__main__":
    app.run(debug = True)