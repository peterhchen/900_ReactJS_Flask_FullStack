import { useState, useEffect } from 'react';
const useFetch = (url) => {
    const [data, setData] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);
    useEffect(() => {
        const abortCont = new AbortController();
        setTimeout(() => {
            //fetch('http://localhost:8000/courses')
            fetch(url, { signal: abortCont.signal })
            .then(res => {
                console.log(res)
                if (!res.ok) {
                    throw Error ('Could not fetch the data for resource courses') 
                }
                return res.json();
            })
            .then(data1 => {
                console.log(data1);
                setData(data1);
                setIsLoading(false);
                setError(false);
            })
            .catch (err => { 
                if (err.name === 'AbortError') {
                    console.log('ftech aborted'); 
                    // if the abort happend, we do not want to update the state
                } else {
                    console.log(err.message)
                    setIsLoading(false);
                    setError(err.message);
                }
            })
        }, 1)
        return () => {
            console.log('cleanup');
            abortCont.abort();
        } 
    }, [url]);
    return { data, isLoading, error }
}

export default useFetch;