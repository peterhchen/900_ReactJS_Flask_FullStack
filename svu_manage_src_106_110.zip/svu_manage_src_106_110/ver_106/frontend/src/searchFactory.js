let sequence = 0;
let course_no = ['CS450','CS440',
                'CS500', 'CS520',
                'CS540', 'CS502',
                'CS500', 'CS520',
                'CS596-003', 'CS596-005',
                'CS596-007', 'CS596-009',
                'CS596-011', 'CS596-026',
                'CS596-027', 'CS596-028',
                'CS596-039', 'CS596-041'
            ];
let course_title = ['Computer Architecture I','Computer Network I',
            'Operating System Design', 'Database System Design',
            'Computer Networks II', 'Design and Analysis of Algorithm', 
            'SP: Data Pipeline: Apache Airflow', 'SP: Machine Learning: Scikit-learn', 
            'SP: Deep Learning: PyTorch, Tensoflow, and Keras', 'SP: Reinforcement Learning: OpenAI and PyTorch', 
            'SP: Full Stack Development: ReactJS, Python, and Flask', 'SP: OpenStack: Build Private Cloud',
            'SP: Software Defined Networking', 'P: Hadoop and Big Data: Manage Cloud by Kafka, Spark, Flume, Zookeeper, HDFS', 
            'SP: Deep Learning: PyTorch, Tensoflow, and Keras', 'SP: Reinforcement Learning: OpenAI and PyTorch', 
            'SP: Web Applicaiton Testing: Selenium, Docker, CI/CD', 'SP: High Performace Networks'
            ];
let trimester = ['Spring', 'Summer', 'Fall'];
let time= ['Mon 6-9pm','Tue 6-9pm','Wed 6-9pm','Thu 6-9pm','Fri 6-9pm', 'Sat 9-12pm', 'Sat 6-9pm'];

const createOneSearchRecord = () => {
    const res = {
        id: sequence,
        trimester: trimester[sequence % trimester.length],
        year: 2023,
        course_no: course_no[sequence % course_no.length],
        title: course_title[sequence % course_title.length],
        time: time[sequence % time.length],
        credit_attempted: 3
    }
    console.log ('createOneCourseRecord => res:', res)
    sequence++;
    return res;
}
export default createOneSearchRecord;