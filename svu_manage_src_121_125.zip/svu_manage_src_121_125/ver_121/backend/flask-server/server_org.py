"""
Description: Flask back end processing
03/15/2023: by Peter Hanping Chen
"""
# CORS (Cross Origin Resource Sharing)
# Allow server (flask) to cross any orgins (domain, scheme, or port).
# https://www.youtube.com/watch?v=tPKyDM0qEB8
# > pip install flask-cors
import os
from datetime import datetime
import shutil
import json
import subprocess
# from datetime import datetime
from flask import Flask
from flask import request
from flask_cors import CORS

# move the flask message out of screen.
import logging

app = Flask (__name__)
CORS(app)  # make every URL endpoint allowed cross origin

# https://www.youtube.com/watch?v=e9jXngbW1RM
# https://www.geeksforgeeks.org/python-using-2d-arrays-lists-the-right-way/

class Student:
    """
    Description:
    Class Student
    """
    def __init__ (self, student_id='', fname='', lname='', dob='', adm_year='',
                  adm_trimester='', gpa=''):
        self.student_id = student_id
        self.fname = fname
        self.lname = lname
        self.dob = dob
        self.adm_year = adm_year
        self.adm_trimester = adm_trimester
        self.gpa = gpa

class Course:
    """
    Description:
    Course
    """
    def __init__ (self, course_id, course_year, course_trimester, course_no, course_title,
                  credit_attempted, creadit_earned, grade, points):
        self.course_id = course_id
        self.course_year = course_year
        self.course_trimester = course_trimester
        self.course_no = course_no
        self.course_title = course_title
        self.credit_attempted = credit_attempted
        self.credt_earned = creadit_earned
        self.grade = grade
        self.points = points

def get_transcript_by_student_id(student_id):
    """
    Description:
    Get transcript from student_id
    """
    if len(student_id) <= 10:
        # get '15' (index = 0 and 1) from student_id = '1503011365'
        adm_year = '20' + student_id[0:2]
    else:
        # get '2115' (index = 0, 1, 2, 3) from student_id ='211503011365'
        adm_year = student_id[0:5]
    print('adm_year:', adm_year)
    # student = Student(student_id, name, fname, lname, dob, adm_year, adm_trimester, '')
    f_n = student_id + '.json'
    path_fn = os.path.join ('./svu_data/transcript', adm_year, student_id, f_n)
    print('path_fn:', path_fn)
    with open (path_fn, encoding='utf-8') as s_file:
        json_data = json.load(s_file)
        print("json_data['course'][:3]:", json_data['course'][:3])
    return json_data

def get_transcript_by_name(fname, lname, dob):
    """
    Description:
    Get json_data by first name, lasname, dob.
    The transcript is an array that may contains 0 student to n students.
    """
    grep_lines = []
    path_fns = []
    json_data_arr = []
    # perform "grep -r kw ./svu_data/* | grep KEESARA | grep SOHAN"
    # | grep 03-05-1993
    # > /svu_data/transcript/2015/1503011365/1503011365.json:
    # >    "kw": "1503011365; SOHAN BHARGAV KEESARA; 03-05-1993",
    # > who # for multiple user
    # > timedate for different time access
    # Note: Use array to store the result. It can more than one.
    cmd = ''
    if fname or lname or dob:
        if fname and lname and dob:
            cmd = 'grep -r kw ./svu_data/* | grep ' + lname + ' | grep ' + fname + \
                ' | grep ' + dob
        elif fname and lname:
            cmd = 'grep -r kw ./svu_data/* | grep ' + lname + ' | grep ' + fname
        elif fname:
            cmd = 'grep -r kw ./svu_data/* | grep ' + fname
        elif lname:
            cmd = 'grep -r kw ./svu_data/* | grep ' + lname
    output = subprocess.check_output(cmd, shell=True).decode()
    # Convert byte code into string
    print('output:')
    print(output)
    # './svu_data/transcript/2023/2303011365/2303011365.json:    "kw": "2303010001; Jason J. Chen ; 03-15-1991",
    # ./svu_data/transcript/2023/2303011365/2303011365_arr.json:            "kw": "2303010001; Jason J. Chen ; 03-15-1991",'
    lines = output.split(',')
    for line in lines: 
        print('line:', line)
        # line: ./svu_data/transcript/2023/2303011365/2303011365.json:    "kw": "2303010001; Jason J. Chen ; 03-15-1991"
        # line: 
        # ./svu_data/transcript/2023/2303011365/2303011365_arr.json:            "kw": "2303010001; Jason J. Chen ; 03-15-1991"
        # line: 
        if './svu_data' in line:
            path_fns.append(line.split(':')[0])

    print('path_fns:', path_fns)
    # path_fns: ['./svu_data/transcript/2025/2303011365/2303011365.json', 
    # '\n./svu_data/transcript/2025/2303011365/2303011365_arr.json'
    for path_fn in path_fns:
        print('path_fn1:', path_fn)
        path_fn = path_fn.replace("\n", "") # remove '\n'
        print('path_fn:', path_fn)
        with open (path_fn, encoding='utf-8') as s_file:
            load_data = json.load(s_file)
            print('load_data:', load_data)
            json_data_arr.append(load_data)

    print('json_data_arr:', json_data_arr)
    return json_data_arr

# API Route
@app.route ("/search", methods=["GET", "POST"])
def search():
    """
    Description:
    search
    """
    print('/search => search()')
    student_id = request.args.get ('STUDENT_ID')
    fname = request.args.get('FNAME')
    lname = request.args.get('LNAME')
    dob = request.args.get('DOB')
    cmd = request.args.get('CMD')
    print("Flask => STUDENT_ID:", student_id)
    print("Flask => Name:", fname)
    print("Flask => Name:", lname)
    print("Flask => DOB:", dob)
    print("Flask => CMD:", cmd)

    # student_id, name, fname, lname, dob, adm_year, adm_trimester, gpa):
    #search_transcript = []
    adm_trimester = 'Fall'
    #student_id = '1503011365'
    if len(student_id) > 0:
        json_data = get_transcript_by_student_id(student_id)
    else:
        json_data = get_transcript_by_name(fname, lname, dob)

    return json_data

@app.route ("/save", methods=["GET", "POST"])
def save():
    """
    Description:
    save
    """
    print('/save => save()')
    student_id = request.args.get ('STUDENT_ID')
    fname = request.args.get('FNAME')
    mname = request.args.get('MNAME')
    lname = request.args.get('LNAME')
    dob = request.args.get('DOB')
    row_data = request.args.get('ROW_DATA')
    cmd = request.args.get('CMD')
    #print("Flask => STUDENT_ID:", student_id)
    #print("Flask => firstName:", fname)
    #print("Flask => middleName:", mname)
    #print("Flask => lastName:", lname)
    #print("Flask => DOB:", dob)
    #print("Flask => row_data:", row_data)
    #print("Flask => CMD:", cmd)

    # student_id, name, fname, lname, dob, adm_year, adm_trimester, gpa):
    #search_transcript = []
    adm_trimester = 'Fall'
    #student_id = '1503011365'
    print('Save row_data: ', row_data)
    if len(student_id) <= 10:
        # get '15' (index = 0 and 1) from student_id = '1503011365'
        adm_year = '20' + student_id[0:2]
    else:
        # get '2115' (index = 0, 1, 2, 3) from student_id ='211503011365'
        adm_year = student_id[0:5]
    print('adm_year:', adm_year)
    # student = Student(student_id, name, fname, lname, dob, adm_year, adm_trimester, '')

    path = os.path.join ('./svu_data/transcript', adm_year, student_id)
    path_log = os.path.join (path, "log")
    print('path:', path)
    isPathExist = os.path.exists (path)
    if not isPathExist: 
        os.makedirs(path)
        print("The new directory " + path + " is created")
    isPathLogExist = os.path.exists (path_log)

    f_n = student_id + '.json'
    path_fn = os.path.join (path, f_n)
    print('path_fn:', path_fn)
    if not isPathLogExist: 
        os.makedirs(path_log)
        print("The new log directory " + path_log + " is created")
        now = datetime.now()
        dt_string = now.strftime("%Y_%m_%d_%H_%M_%S")
        path_fn_timestamp = path_fn + '_' + dt_string
        os.rename(path_fn, path_fn_timestamp)
        shutil.move(path_fn_timestamp, path_log)
    print()
    print()
    print('==============================================')
    data = {}
    # "kw": "2303010001; Jason J. Chen ; 03-15-1991",
    fullname = ''
    fullname = str(fname) + ' ' + str (mname) + ' ' + str (lname)
    print('fullname: ', fullname)
    data['kw'] = str(student_id) + '; ' + fullname + ' ; ' + str (dob)
    print('data["kw"]: ', data['kw'])
    # "STUDENT_ID": "2303010001", 
    data['STUDENT_ID'] = str(student_id)
    print('data["STUDENT_ID"]: ', data["STUDENT_ID"])
    # "name": "Jason J. Chen",
    data['name'] = fullname
    print('data["name"]: ', data["name"])
    # "DOB": "03-15-1991",
    data["DOB"] = dob
    print('data["DOB"]: ', data["DOB"])
    print('==============================================')
    print('row_data:', row_data)
    data["course"] = row_data
    #for ele in row_data:
    #    print ('ele:', ele)
    #    data['course'].append(ele)
    print('data["course"]: ', data["course"])
    print('==============================================')
    print('data: ', data)
    data_s = str(data)
    print('==============================================')
    print('data_s: ', data_s)
    data_s_new1 = data_s.replace(',', ',\n')
    print('==============================================')
    print('data_s_new1: ', data_s_new1)
    data_s_new2 = data_s_new1.replace ('{', '{\n')
    print('==============================================')
    print('data_s_new2: ', data_s_new2)
    data_s_new3 = data_s_new2.replace('}', '}\n')
    print('==============================================')
    print('data_s_new3: ', data_s_new3)
    data_s_new5 = data_s_new3.replace("]'", ']')
    print('==============================================')
    print('data_s_new5: ', data_s_new5)
    data_s_new = data_s_new5.replace("'[", '[')
    print('==============================================')
    print('data_s_new: ', data_s_new)
    #lines = data_s_new.split('\n')
    #print('lines: ', lines)
    print('==============================================')
    with open (path_fn, "w+", encoding='utf-8') as s_file:
    #    for line in lines:
    #        s_file.write(line)
        s_file.write(data_s_new)
    print('SAVE_OK')
    json_data = ['SAVE_OK']
    return json_data

@app.route ("/course")
def create():
    """
    Description:
    create
    """
    return {
        "course": [
        {
            "id": 0, "trimester": "Fall", "year": 2023, "course_no": "CS450",
            "title": "Computer Architecture I",
            "time": "Mon 6-9pm", "credit_attempted": 3
        },
        {
            "id": 1, "trimester": "Fall", "year": 2023, "course_no": "CS440",
            "title": "Computer Networks I",
            "time": "Tue 6-9pm", "credit_attempted": 3
        },
        {
            "id": 2, "trimester": "Fall", "year": 2023, "course_no": "CS500",
            "title": "Operating System Design",
            "time": "Wed 6-9pm", "credit_attempted": 3
        },
        {
            "id": 3, "trimester": "Fall", "year": 2023, "course_no": "CS520",
            "title": "Database System Design",
            "time": "Thu 6-9pm", "credit_attempted": 3
        },
        {
            "id": 4, "trimester": "Fall", "year": 2023, "course_no": "CS540",
            "title": "Computer Networks II",
            "time": "Fri 6-9pm", "credit_attempted": 3
        },
        {
            "id": 5, "trimester": "Fall", "year": 2023, "course_no": "CS502",
            "title": "Design and Analysis of Algorithm",
            "time": "Sat 6-9pm", "credit_attempted": 3
        },
        {
            "id": 6, "trimester": "Fall", "year": 2023, "course_no": "CS596-003",
            "title": "SP: Data Pipeline: Apache Airflow",
            "time": "Mon 6-9pm", "credit_attempted": 3
        },
        {
            "id": 7, "trimester": "Fall", "year": 2023, "course_no": "CS596-005",
            "title": "SP: Machine Learning: Scikit-learn",
            "time": "Tue 6-9pm", "credit_attempted": 3
        },
        {
            "id": 8, "trimester": "Fall", "year": 2023, "course_no": "CS596-007",
            "title": "SP: Deep Learning: PyTorch, Tensoflow, and Keras",
            "time": "Wed 6-9pm", "credit_attempted": 3
        },
        {
            "id": 9, "trimester": "Fall", "year": 2023, "course_no": "CS596-009",
            "title": "SP: Reinforcement Learning: OpenAI and PyTorch",
            "time": "Thu 6-9pm", "credit_attempted": 3
        },
        {
            "id": 10, "trimester": "Fall", "year": 2023, "course_no": "CS596-011",
            "title": "SP: Full Stack Development: ReactJS, Python, and Flask",
            "time": "Fri 6-9pm", "credit_attempted": 3
        },
        {
            "id": 11, "trimester": "Fall", "year": 2023, "course_no": "CS596-026",
            "title": "SP: OpenStack: Build Private Cloud",
            "time": "Sat 6-9pm", "credit_attempted": 3
        },
        {
            "id": 12, "trimester": "Fall", "year": 2023, "course_no": "CS596-027",
            "title": "SP: Software Defined Networking",
            "time": "Mon 6-9pm", "credit_attempted": 3
        },
        {
            "id": 13, "trimester": "Fall", "year": 2023, "course_no": "CS596-028",
            "title": "SP: Hadoop and Big Data: Kafka, Spark, Flume, Zookeeper, HDFS",
            "time": "Tue 6-9pm", "credit_attempted": 3
        },
        {
            "id": 14, "trimester": "Fall", "year": 2023, "course_no": "CS596-039",
            "title": "SP: Web Applicaiton Testing: Selenium, Docker, CI/CD",
            "time": "Wed 6-9pm", "credit_attempted": 3
        },
        {
            "id": 15, "trimester": "Fall", "year": 2023, "course_no": "CS596-041",
            "title": "SP: High Performace Networks",
            "time": "Thu 6-9pm", "credit_attempted": 3
        }
        ]
    }

# API Route
@app.route ("/transcript")
def transcript():
    """
    Descripiotn:
    transcript
    """
    transcript_a = []
    student = Student()
    transcript_a.append(student)
    return {
        "kw": "1503011365; SOHAN BHARGAV KEESARA; 03-05-1993",
        "ID": "1503011365",
        "name": "SOHAN BHARGAV KEESARA",
        "DOB": "03-05-1993",
        "transcript": [
        {
            "trimester": "Transfer", "year": 2015, "course_no": "EE220",
            "title": "RFIC Design I",
            "credit_attempted": "TR", "credit_earned": 3, "grade": "TR", "points": "TR",
            "tid": 1
        },
        {
            "trimester": "Transfer", "year": 2015, "course_no": "EE250",
            "title": "Prob Ran Vari & St P",
            "credit_attempted": "TR", "credit_earned": 3, "grade": "TR", "points": "TR",
            "tid": 2
        }]
    }


@app.route ("/rowdataex", methods=["GET", "POST"])
def url_param_rowdata():
    """
    Description:
    URL param
    """
    student_id = request.args.get ('STUDENT_ID')
    name = request.args.get('Name')
    dob = request.args.get('DOB')
    print("Flask => STUDENT_ID:", student_id)
    print("Flask => Name:", name)
    print("Flask => DOB:", dob)
    return {"STUDENT_ID": student_id, "Name": name, "DOB": dob }

if __name__ == "__main__":
    app.run(debug = True)
