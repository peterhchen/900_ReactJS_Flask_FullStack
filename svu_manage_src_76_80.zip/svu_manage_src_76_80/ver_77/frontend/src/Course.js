import React, { useState, useRef, useEffect, useMemo, useCallback } from 'react';
import { render } from 'react-dom';
import { AgGridReact } from 'ag-grid-react'; // the AG Grid React Component
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS
import createOneCourseRecord from './courseFactory';
import createOneCarRecord from './carFactory';
let courses = [...new Array(9)].map(() => createOneCourseRecord());
const Course = () => {
  const [error, setError] = useState(null);
  const gridRef = useRef(); // Optional - for accessing Grid's API

  const [rowData, setRowData] = useState(); // Set rowData to Array of Objects, one Object per Row
  const [columnDefs, setCoulmnDefs] = useState ([
    {headerName: "ID", field: 'id', sortable: true, checkboxSelection: true, flex: 5},
    {headerName: "Trimester", field: 'trimester', flex: 8},
    {headerName: "Year", field: 'year', flex: 8},
    {headerName: "Course No", field: 'course_no', flex: 10}, 
    {headerName: "Course Title", field: 'title', flex: 30},
    {headerName: "Time", field: 'time', flex: 8},
    {headerName: "Credit", field: 'credit_attempted', flex: 5},
  ]);
  
  //setColumnDefs(columns);
  // DefaultColDef sets props common to all Columns
  const defaultColDef = useMemo( ()=> ({
      sortable: true,  editable: true, filter: true, floatingFilter: true
    }));

  // Example of consuming Grid Event
  const cellClickedListener = useCallback( event => {
    console.log('cellClicked', event);
  }, []);

  useEffect(() => {
    setRowData(courses);
  }, []);

  const onInsertOne = useCallback( ()=> {
    const newRecord = createOneCourseRecord();
    console.log('onInsertOne => newRecord:', newRecord)
    console.log('onInsertOne => before courses:', courses)
    courses = [newRecord, ...courses];
    console.log('onInsertOne => after courses:', courses)
    setRowData(courses);
  });

  const getRowId = useCallback( params => {
    return params.data.id;
  });

  const onRemove = useCallback (() => {
    const selectedNodes 
      = gridRef.current.api.getSelectedNodes();
    console.log ("onRemove => selectedNodes: ", selectedNodes)
    const selectedIds = selectedNodes.map (
      node => node.data.id);
    console.log ("onRemove => selectedIds: ", selectedIds)
    // Initially, indexOf = -1, when selected, ar-grid assign indexOf to to index, 
    //courses = courses.filter (
    //    course => console.log ('selectedIds.indexOf(course.id):', selectedIds.indexOf(course.id))
    //);
    // Only -1 is keep in the new courses.
    courses = courses.filter (
      course => selectedIds.indexOf(course.id) < 0
    );
    console.log ("onRemove => courses: ", courses)
    setRowData(courses);
  });

  const onReverse = useCallback (() => {
    courses = [...courses].reverse();
    setRowData(courses);
  });

  return (
    <div>
      <div>
        <button onClick={onInsertOne}>Insert One</button>
        <button onClick={onReverse}>Reverse</button>
        <button onClick={onRemove}>Remove Selected</button>
      </div>
      {/* On div wrapping Grid a) specify theme CSS Class Class and b) sets Grid size */}
      <div className="ag-theme-alpine" style={{width: 1200, height: 750}}>
        <AgGridReact
            ref={ gridRef } // Ref for accessing Grid's API
            asyncTransactionWaitMillis={5000}
            getRowId={ getRowId }
            rowData={ rowData } // Row Data for Rows
            columnDefs = { columnDefs } // Column Defs for Columns
            defaultColDef={ defaultColDef } // Default Column Properties
            animateRows={ true } // Optional - set to 'true' to have rows animate when sorted
            rowSelection='multiple' // Options - allows click selection of rows
            />
      </div>
    </div>
  );
}

export default Course;