import CourseList from './CourseList';
import useFetch from './useFetch';

const Transcript = () => {
    //const [courses, setCourses] = useState(null);
    //const [name, setName] = useState('Simon');
    const { data: courses, isLoading, error } = useFetch('http://localhost:8000/courses');
    //const handleDelete = (id) => {
    //    const newCourses = courses.filter(course => course.id !== id)
    //    setCourses (newCourses);
    //}
    return (
        <div className = "home">
            { error && <div> { error }</div>}
            { isLoading && <div>Loading ...</div>}
            {/*
            { courses && <CourseList courses = { courses } title = {"SVU courses"} handleDelete = {handleDelete} />}
            */}
            { courses && <CourseList courses = { courses } title = {"SVU courses"} />}
            {/*
            <button onClick = {() => setName('Jerry')}>Change Name</button>
            <p>{ name }</p>
            */}
        </div>
    );
}
 
export default Transcript;