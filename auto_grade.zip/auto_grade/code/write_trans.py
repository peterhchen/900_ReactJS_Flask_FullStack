"""
Write Transcript
01/12/2023 created by Peter Hanping Chen
"""
import os
import json
from PIL import Image
import xlsxwriter
import read_grade

class WriteTrans():
    """
    Write Transcript
    """
    def __init__(self):
        pass

    @staticmethod
    def write_summary (w_s, off_set, total_transfer_credit, total_cm_credit, total_cm_gpa):
        """
        print transfer, total cumulative credit, gpa
        """
        row = off_set + 1
        col = 0
        print("Writing Excel Transcript Summary...")
        w_s.write(row, col, "TRANSCRIPT SUMMARY:")
        w_s.write(row, col+1, "TRANSFER CREDIT: " + str(total_transfer_credit))
        w_s.write(row, col+2, "CUMULATIVE CREDIT: " + str(total_cm_credit))
        total_cm_gpa_str = f"{total_cm_gpa:.2f}"
        w_s.write(row, col+3, "GPA: " + total_cm_gpa_str)

    @staticmethod
    def write_transfer_info(w_b, w_s, off_set, transfer_info):
        """
        Write transfer information
        """
        print("Writing Excel Transfer...")
        row = off_set
        col = 0
        total_transfer_credit = 0
        cell_border_format = w_b.add_format({'border': 1})               # add text cell border
        cell_text_center_format = w_b.add_format({'align': 'center'})    # Add text center
        # Border and center
        cell_border_text_center_format = w_b.add_format({'border': 1, 'align': 'center'})
        w_s.write(row, col, "COURSE NO", cell_border_format)
        w_s.write(row, col+1, "COURSE TITLE", cell_border_format)
        w_s.write(row, col+2, "CREDIT ATTEMPTED", cell_border_text_center_format)
        w_s.write(row, col+3, "CREDIT EARNED", cell_border_text_center_format)
        w_s.write(row, col+4, "GRADE", cell_border_text_center_format)
        w_s.write(row, col+5, "POINTS", cell_border_text_center_format)
        row += 1
        for t_ele in transfer_info:
            w_s.write(row, col, str(t_ele.course_id))
            w_s.write(row, col+1, str(t_ele.course_title))
            w_s.write(row, col+3, str(t_ele.credit_earn), cell_text_center_format)
            w_s.write(row, col+4, t_ele.course_grade, cell_text_center_format)
            if int(t_ele.credit_earn) > 0:
                total_transfer_credit += int(t_ele.credit_earn)
            row += 1
        w_s.write(row, col, "TOTAL TRANSFER CREDITS: " + str(total_transfer_credit))
        transfer_off_set = row
        return transfer_off_set

    @staticmethod
    def write_course_tm_cm_info(w_b, w_s, off_set, c_trimester_year_list, tm_cm_info):
        """
        Write tm/cm (trimester/cumulative) at specified trimester and year
        """
        print("Writing Excel Ttrimester/Cumulative Info...")
        r_g = read_grade.ReadGrade()
        row = off_set
        col = 0
        tm_course_num = 0
        row += 1
        cell_border_format = w_b.add_format({'border': 1})               # add text cell border
        cell_text_center_format = w_b.add_format({'align': 'center'})    # Add text center
        # Border and center
        cell_border_text_center_format = w_b.add_format({'border': 1, 'align': 'center'})
        w_s.write(row, col, "COURSE NO", cell_border_format)
        w_s.write(row, col+1, "COURSE TITLE", cell_border_format)
        w_s.write(row, col+2, "CREDIT ATTEMPTED", cell_border_text_center_format)
        w_s.write(row, col+3, "CREDIT EARNED", cell_border_text_center_format)
        w_s.write(row, col+4, "GRADE", cell_border_text_center_format)
        w_s.write(row, col+5, "POINTS", cell_border_text_center_format)
        row += 1
        tm_course_num = 0
        cell_bold_format = w_b.add_format({'bold': True})  # cell bold text
        for tm_cm in tm_cm_info:
            # ws.write(row, col+6, print_trimester_year_flag)e
            max_course_cnt = r_g.find_max_course_cnt_in_tm (c_trimester_year_list, tm_cm_info)
            for trimester_year in c_trimester_year_list:
                if tm_cm.year in trimester_year and tm_cm.trimester in trimester_year:
                    if tm_course_num == 0:
                        w_s.write(row, col, str(tm_cm.year) + ' ' + str(tm_cm.trimester),
                        cell_bold_format)
                        row += 1
                    tm_course_num += 1
                    w_s.write(row, col, tm_cm.course_id)
                    w_s.write(row, col+1, tm_cm.course_title)
                    w_s.write(row, col+2, tm_cm.credit_attempt, cell_text_center_format)
                    w_s.write(row, col+3, tm_cm.credit_earn, cell_text_center_format )
                    w_s.write(row, col+4, tm_cm.course_grade, cell_text_center_format )
                    w_s.write(row, col+5, tm_cm.course_point, cell_text_center_format )
                    row += 1
                    if tm_course_num == max_course_cnt:
                        tm_course_num = 0
                        w_s.write(row, col, "TRIMESTER TOTALS")
                        w_s.write(row, col + 2, tm_cm.tm_credit_attempt, cell_text_center_format)
                        w_s.write(row, col + 3, tm_cm.tm_credit_earn, cell_text_center_format)
                        w_s.write(row, col + 4, tm_cm.tm_grade, cell_text_center_format)
                        w_s.write(row, col + 5, tm_cm.tm_point, cell_text_center_format)
                        row += 1
                        w_s.write(row, col, "CUMULATIVE TOTALS")
                        w_s.write(row, col + 2, tm_cm.cm_credit_attempt, cell_text_center_format)
                        w_s.write(row, col + 3, tm_cm.cm_credit_earn, cell_text_center_format)
                        w_s.write(row, col + 4, tm_cm.cm_grade, cell_text_center_format)
                        w_s.write(row, col + 5, tm_cm.cm_point, cell_text_center_format)
                        row += 2
        tm_cm_off_set = row
        return tm_cm_off_set

    @staticmethod
    def write_excel_header_info(w_s, off_set, reg_jpg, def_col1_width, header_info):
        """
        Write student basic information (header_info)
        """
        print("Writing Excel Header Info...")
        row = off_set
        w_s.write(row, 0,'PHOTO')
        # Resize the image height
        i_m = Image.open(reg_jpg)
        im_width, im_height = i_m.size
        # print('im_width: ', im_width, 'im_height: ', im_height)
        # print('def_col1_width: ', def_col1_width)
        x_offset = def_col1_width * 0.1
        y_offset = im_height * 0.1
        if im_width > def_col1_width:
            w_s.set_row(row, 1, im_width)
            x_offset = im_width * 0.1
        w_s.set_row(row, im_height)
        w_s.insert_image(row, 1, reg_jpg, {'x_offset': x_offset, 'y_offset': y_offset })
        row = off_set + 1
        col = 0
        for header_line in header_info:
            header_json = json.loads(header_line)
            for key, value in header_json.items():
                #print(f"{key + ': ':<20}{value:<20}")
                w_s.write(row, col, key)
                w_s.write(row, col+1, value)
                row += 1
        header_off_set = row
        return header_off_set

    @staticmethod
    def write_excel_trans (reg_fn, header_info, c_trimester_year_list, tm_cm_info, transfer_info, \
        total_transfer_credit, total_cm_credit, total_cm_gpa):
        """
        write_transcript in excel format
        """
        #print('reg_fn:', reg_fn)
        #print("c_trimester_year_list:", c_trimester_year_list)
        #print('tm_cm_info:', tm_cm_info)
        #print("transfer_info:", transfer_info)
        # Create an new Excel file and add a worksheet.
        path = os.path.dirname(os.path.abspath(reg_fn))
        trans_name  = os.path.join(path, 'transcript.xlsx')
        reg_jpg  = os.path.join(path, 'register.jpg')
        #print('trans_name:', trans_name)
        #print('../reg_trans/2015/1503011365/transcript.xlsx')
        #print('reg_jpg :', reg_jpg)
        #workbook = xlsxwriter.Workbook('../reg_trans/2015/1503011365/transcript.xlsx')
        workbook = xlsxwriter.Workbook(trans_name)
        worksheet = workbook.add_worksheet()
        # Resize column 0 width
        worksheet.set_column(0, 0, 20)
        # Resize column 1 width
        def_col1_width = 40  # default column 1 width = 40
        worksheet.set_column(1, 1, def_col1_width)
        worksheet.set_column(2, 2, 30)
        worksheet.set_column(3, 3, 30)
        # Insert an image.
        w_t = WriteTrans()
        off_set= 0   # student ID report offset = 0
        header_off_set = w_t.write_excel_header_info(worksheet, off_set, reg_jpg, \
            def_col1_width, header_info)
        tm_cm_off_set = w_t.write_course_tm_cm_info(workbook, worksheet, header_off_set, \
            c_trimester_year_list, tm_cm_info)
        # print("transfer_info:", transfer_info)
        if not transfer_info: # check if is is empty info.
            w_t.write_summary(worksheet, tm_cm_off_set, total_transfer_credit, \
            total_cm_credit, total_cm_gpa)
        else:
            # Add page break
            worksheet.set_h_pagebreaks([tm_cm_off_set])
            # print header
            transfer_header_off_set = \
                w_t.write_excel_header_info(worksheet, tm_cm_off_set, reg_jpg, \
                    def_col1_width, header_info)
            # print transer
            transfer_off_set = w_t.write_transfer_info(workbook, worksheet, \
                transfer_header_off_set, transfer_info)
            w_t.write_summary(worksheet, transfer_off_set, total_transfer_credit, \
                total_cm_credit, total_cm_gpa)
        workbook.close()

if __name__ == "__main__":
    # Test
    # Create an new Excel file and add a worksheet.
    workbook_t = xlsxwriter.Workbook('../reg_trans/2015/1503011365/Write.xlsx')
    worksheet_t = workbook_t.add_worksheet()

    # Widen the first column to make the text clearer.
    worksheet_t.set_column('A:A', 30)

    # Insert an image.
    worksheet_t.write('A2', 'Insert an image in a cell:')
    worksheet_t.insert_image('B2', '../reg_trans/2015/1503011365/register.jpg')

    # Insert an image offset in the cell.
    worksheet_t.write('A12', 'Insert an image with an offset:')
    worksheet_t.insert_image('B12', '../reg_trans/2015/1503011365/register.jpg', \
        {'x_offset': 15, 'y_offset': 10})

    # Insert an image with scaling.
    worksheet_t.write('A23', 'Insert a scaled image:')
    worksheet_t.insert_image('B23', '../reg_trans/2015/1503011365/register.jpg', \
        {'x_scale': 0.5, 'y_scale': 0.5})

    workbook_t.close()
