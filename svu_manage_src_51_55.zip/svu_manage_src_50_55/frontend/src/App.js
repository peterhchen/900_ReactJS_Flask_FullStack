import Navbar from './Navbar';
import Transcript from './Transcript';
import Register from './Register';
import TranscriptDetails from './TranscriptDetails';
import { useEffect } from 'react';

import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';

function App() {
  useEffect(() => {
    // In package.json, we set "proxy": "http://localhost:5000",
    fetch('/transcripts')
    .then(response => response.json()
    .then(data => {
      console.log('data:', data)
    }))
  }, [])

  return (
    <div className="App">
      <Router>
        <Navbar />
        <div className="content">
            <Routes>
              <Route path ="/register" element={ <Register /> } />
              <Route exact path ="/transcript" element={ <Transcript /> } />
              <Route path ="/transcriptDetails/" element={ <TranscriptDetails /> } />
              <Route path ="/transcriptDetails/:id" element={ <TranscriptDetails /> } />
            </Routes>
        </div>
      </Router>
    </div>

  );
}

export default App;
