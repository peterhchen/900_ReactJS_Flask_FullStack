1. go to backend directory:
> cd ~/work/svu_manage/backend/flask-server 
> source venv/bin/activate
> python3 server.py
>> http://127.0.0.1:5000
2. go to frontend directory:
start the chrome browser
> cd ~/work/svu_manage/frontend
> npm install (if node_modules is missing)
> npm start
