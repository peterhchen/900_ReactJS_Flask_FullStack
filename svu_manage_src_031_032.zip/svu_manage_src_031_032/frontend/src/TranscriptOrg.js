import { useState, useEffect } from 'react'
import CourseList from './CourseList'
const Transcript = () => {
    const [courses, setCourses] = useState(null);
    const [name, setName] = useState('Simon');
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);

    const handleDelete = (id) => {
        const newCourses = courses.filter(course => course.id !== id)
        setCourses (newCourses);
    }

    useEffect(() => {
        setTimeout(() => {
            fetch('http://localhost:8000/transcripts')
            .then(res => {
                console.log(res)
                if (!res.ok) {
                    throw Error ('Could not fetch the data for resource transcripts') 
                }
                return res.json();
            })
            .then(data => {
                console.log(data);
                setCourses(data);
                setIsLoading(false);
                setError(false);
            })
            .catch (err => { 
                console.log(err.message)
                setIsLoading(false);
                setError(err.message);
            })
        }, 1)
    }, []);

    return (

        <div className = "home">
            { error && <div> { error }</div>}
            { isLoading && <div>Loading ...</div>}
            { courses && <CourseList courses = { courses } title = {"SVU courses"} handleDelete = {handleDelete} />}
            <button onClick = {() => setName('Jerry')}>Change Name</button>
            <p>{ name }</p>
        </div>
    );
}
 
export default Transcript;