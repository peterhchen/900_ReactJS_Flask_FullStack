import { useState, useEffect } from 'react'
import CourseList from './CourseList'

const cList = [
    { 
        "course_no_title": "CE600 Computer Architecture I",
        "trimester": "2015 Fall Trimester", "credit": 3, "id": 1
    },
    {
        "course_no_title": "CS440 Computer Networks I",
        "trimester": "2015 Fall Trimester",
        "credit": 3, "id": 2
    },
    {
        "course_no_title": "CS596-012 SP: XML and Application",
        "trimester": "2015 Fall Trimester",
        "credit": 3,
        "id": 3
    }];

const Transcript = () => {
    const [courses, setCourses] = useState(null);
    const [courseList, setCourseList] = useState (cList);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);
    const [courseNoTitle, setCourseNoTitle] = useState(cList[0].course_no_title);

    const handleDelete = (id) => {
        const newCourses = courses.filter(course => course.id !== id)
        setCourses (newCourses);
    }

    const handleAdd = (item) => {
        console.log('handleAdd => item', item)
        console.log('handleAdd => ...courses', ...courses)
        setCourseList(courses => [...courses, item]);
        console.log('handleAdd => courses', courses)
    }

    const handleSubmit = (e) => {
        e.preventDefault();  // Keep data/prevent page refreshing to default. 
        const course = { courses };
        console.log ('course:', course);
    
        fetch('http://127.0.0.1:5000/transcripts/', {
            method: 'POST',
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(course)
        }).then(() => {
            console.log('new course added');
        })
    }

    useEffect(() => {
        setTimeout(() => {
        fetch('http://127.0.0.1:5000//transcripts/')
            .then(res => {
                console.log(res)
                if (!res.ok) {
                    throw Error ('Could not fetch the data for resource transcripts') 
                }
                return res.json();
            })
            .then(data => {
                console.log(data);
                setCourses(data);
                setIsLoading(false);
                setError(false);
            })
            .catch (err => { 
                console.log(err.message)
                setIsLoading(false);
                setError(err.message);
            })
        }, 1)
    }, []);

    return (
        <div className = "home">
            <h2>Transcript</h2>
            <form onSubmit = { handleSubmit }>
                { error && <div> { error }</div>}
                { isLoading && <div>Loading ...</div>}
                { courses && <CourseList courses = { courses } title = {"SVU courses"} handleDelete = {handleDelete}/>}
                <div>
                    <label>Course No: </label>
                    <select
                        value = { courseList.course_no_title }
                        onChange = { (e) => setCourseNoTitle(e.target.value)}>               
                    {
                        courseList.map((item) => 
                            <option key = {item.id} value = { item.course_no_title } > { item.course_no_title }</option>)
                    }
                    
                    </select>                      
                </div>
                {courseNoTitle && <button onClick = {() => handleAdd (courseNoTitle)} > add course</button>}
                <br></br>
                <button>Submit</button>
            </form>
        </div>
    );
}
 
export default Transcript;