import Navbar from './Navbar';
import Transcript from './Transcript';
import Register from './Register';

import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';

function App() {
  return (
    <div className="App">
      <Router>
        <Navbar />
        <div className="content">
            <Routes>
              <Route exact path ="/" element={ <Transcript /> } />
              <Route path ="/register" element={ <Register /> } />
            </Routes>
        </div>
      </Router>
    </div>

  );
}

export default App;
