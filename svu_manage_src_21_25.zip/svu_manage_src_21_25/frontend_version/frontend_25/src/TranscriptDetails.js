import { useParams } from 'react-router-dom';

const TranscriptDetails = () => {
    const { id } = useParams()
    return (  
        <div className="transcript-details">
            <h2>Transcript Details: { id }</h2>
        </div>
    );
}
 
export default TranscriptDetails;