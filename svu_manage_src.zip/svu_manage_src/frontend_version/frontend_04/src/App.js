import './App.css';

const title = 'SVU Management System';
const info = 'Registration and Transcript browser'
// const person = {"Name: ", "peter", "Age: ",  65}
const link = 'http://www.google.com'
function App() {
  return (
    <div className="App">
      <div className="content">
        <h1>{ title }</h1>
        <p>{ info }</p>
        {/* <p> person</p> */}
        <p>{ [1, 2, 3, 4, 5] }</p>
        <p>{ Math.random() * 10 }</p>

        <a href = { link }>Google Site </a>
      </div>
    </div>
  );
}

export default App;
