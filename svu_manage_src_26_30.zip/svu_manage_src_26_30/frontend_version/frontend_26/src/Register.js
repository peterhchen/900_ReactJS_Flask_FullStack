const Register = () => {
    return (  
        <div className="register">
            <h2>Create a New Registration</h2>
        </div>
    );
}
 
export default Register;