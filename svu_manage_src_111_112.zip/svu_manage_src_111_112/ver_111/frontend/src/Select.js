// https://www.youtube.com/watch?v=OTuvp8dCtHQ
import React, { useState} from "react";

const Select = () => {
  const [val, setVal] = useState('')
  const [val2, setVal2] = useState('')
  const data = ['Jason J. Chen', 'Jonathan J. Chen', 'Jessica J. Chen', 'Jasmine J. Chen']

  return (
    <div>
      <select value={val} onChange={(e) => { setVal (e.target.value)} }>
        <option>Selection 1</option>
        <option>Selection 2</option>
        <option>Selection 3</option>
      </select>
      <h1>{val}</h1>
      <br></br>
      <select value={val2} onChange={(e) => { setVal2 (e.target.value)} }>
        {
          data.map((opt) => <option>{opt}</option> )

        }
      </select>
      <h1>{val2}</h1>
    </div>
  )
}

export default Select;