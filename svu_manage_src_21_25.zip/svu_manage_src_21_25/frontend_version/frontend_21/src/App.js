import Navbar from './Navbar';
import Transcript from './Transcript';
import { BrowserRouter, Route, Routes } from 'react-router-dom';

function App() {
  return (
    <div className="App">
      <Navbar />
      <div className="content">
        <BrowserRouter>
          <Routes>
            <Route path ="/" element={ <Transcript /> } />
            <Route path ="/Transcript" element={ <Transcript /> } />
          </Routes>
        </BrowserRouter>
      </div>
    </div>

  );
}

export default App;
