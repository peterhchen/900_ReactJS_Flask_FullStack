import Navbar from './Navbar';
import Course from './Course';
import Transcript from './Transcript';
import Register from './Register';
import Car from './Car';
import TranscriptDetails from './TranscriptDetails';
import { useState, useEffect } from 'react';
import './App.css';

import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';

function App() {
  return (
    <div className="App">
      <Router>
        <Navbar />
        <div className="content">
            <Routes>
              <Route path ="/" element={ <Course /> } />
              <Route path ="/course" element={ <Course /> } />
              <Route path ="/register" element={ <Register /> } />
              <Route exact path ="/transcript" element={ <Transcript /> } />
              <Route path ="/Car" element={ <Car /> } /> 
              <Route path ="/transcriptDetails/" element={ <TranscriptDetails /> } />
              <Route path ="/transcriptDetails/:id" element={ <TranscriptDetails /> } />
            </Routes>
        </div>
      </Router>
    </div>

  );
}

export default App;
