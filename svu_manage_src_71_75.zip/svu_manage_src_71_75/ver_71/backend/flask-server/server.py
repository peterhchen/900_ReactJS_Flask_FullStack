from flask import Flask
from flask import request
app = Flask (__name__)

# API Route
@app.route ("/create")
def create():
    return {
        "create": [
        {
            "trimester": "Fall", "year": 2015, "course_no": "CS450", "title": "Computer Architecture I",
            "cid": 1, "credit_attempted": 3, 
        },
        {
            "trimester": "Fall", "year": 2015, "course_no": "CS440", "title": "Computer Networks I",
            "cid": 2, "credit_attempted": 3, 
        }]
    }

# API Route
@app.route ("/transcript")
def transcript():
    return {
        "kw": "1503011365; SOHAN BHARGAV KEESARA; 03-05-1993",
        "ID": "1503011365", 
        "name": "SOHAN BHARGAV KEESARA",
        "DOB": "03-05-1993",
        "transcript": [
        {
            "trimester": "Transfer", "year": 2015, "course_no": "EE220", "title": "RFIC Design I",
            "credit_attempted": "TR", "credit_earned": 3, "grade": "TR", "points": "TR",
            "tid": 1
        },
        {
            "trimester": "Transfer", "year": 2015, "course_no": "EE250", "title": "Prob Ran Vari & St P",
            "credit_attempted": "TR", "credit_earned": 3, "grade": "TR", "points": "TR",
            "tid": 2
        }]
    }

@app.route ("/search", methods=["GET", "POST"])
def url_param():
    student_ID = request.args.get ('STUDENT_ID')
    name = request.args.get('Name')
    dob = request.args.get('DOB')
    print("Flask => STUDENT_ID:", student_ID)
    print("Flask => Name:", name)
    print("Flask => DOB:", dob)
    return {"STUDENT_ID": student_ID, "Name": name, "DOB": dob }
    
if __name__ == "__main__":
    app.run(debug = True)