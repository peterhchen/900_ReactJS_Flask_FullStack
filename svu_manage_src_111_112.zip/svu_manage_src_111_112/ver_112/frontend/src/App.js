import Navbar from './Navbar';
import Course from './Course';
import Transcript from './Transcript';
import Register from './Register';
import Car from './Car';
import RowSelection from './RowSelection';
import RowDataEx from './RowDataEx';
import TranscriptDetails from './TranscriptDetails';
import Search from './Search';
import Popup from './Popup';
import Select from './Select';
import { useState, useEffect } from 'react';
import './App.css';

import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';

function App() {
  return (
    <div className="App">
      <Router>
        <Navbar />
        <div className="content">
            <Routes>
              <Route path ="/" element={ <Course /> } />
              <Route path ="/course" element={ <Course /> } />
              <Route path ="/register" element={ <Register /> } />
              <Route exact path ="/transcript" element={ <Transcript /> } />
              <Route path ="/search" element={ <Search /> } />
              <Route path ="/select" element={ <Select /> } />
              <Route path ="/popup" element={ <Popup /> } />
              <Route path ="/rowselection" element={ <RowSelection /> } /> 
              <Route path ="/rowdataex" element={ <RowDataEx /> } /> 
              {/* <Route path ="/transcriptDetails/" element={ <TranscriptDetails /> } /> */}
            </Routes>
        </div>
      </Router>
    </div>

  );
}

export default App;
