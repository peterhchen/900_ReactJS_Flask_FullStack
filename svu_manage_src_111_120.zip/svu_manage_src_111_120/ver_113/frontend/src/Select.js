// https://www.youtube.com/watch?v=OTuvp8dCtHQ
// https://www.youtube.com/watch?v=RxHCE35x2vw
// (10:02/24:00)
import React, { useState } from 'react';

const Select = () => {
  const [val, setVal] = useState('')
  const [val2, setVal2] = useState('')
  const [val3, setVal3] = useState('')
  const data = ['Jason J. Chen', 'Jonathan J. Chen', 'Jessica J. Chen', 'Jasmine J. Chen']

  const handleStudentSel = (event) => {
    const getStudentID = event.target.value;
    console.log ('getStudentID:', getStudentID)
    setVal3 (getStudentID)
  }

  return (
    <div>
      <select value={val} onChange={(e) => { setVal (e.target.value)} }>
        <option>Selection 1</option>
        <option>Selection 2</option>
        <option>Selection 3</option>
      </select>
      <h1>{val}</h1>
      <br></br>
      <select value={val2} onChange={(e) => { setVal2 (e.target.value)} }>
        <option>-- Select a Student -- </option>
        {
          data.map((opt) => <option>{opt}</option> )

        }
      </select>
      <h1>{val2}</h1>

      <select value={val3} onChange={(e) => handleStudentSel (e) }>
        <option>-- Select a Student -- </option>
        {
          data.map((opt) => <option>{opt}</option> )
        }
      </select>
      <h1>{val3}</h1>
    </div>
  )
}

export default Select;