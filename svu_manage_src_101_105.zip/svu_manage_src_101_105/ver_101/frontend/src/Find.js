
import './App.css';
import React, { useState, useRef, useEffect, useMemo, useCallback } from 'react';
import { AgGridReact } from 'ag-grid-react'; // the AG Grid React Component
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS
import createOneCourseRecord from './courseFactory';
console.log('createOneCourseRecrod...');
let courses = [...new Array(9)].map(() => createOneCourseRecord());
const Find = () => {
  const gridRef = useRef(); // Optional - for accessing Grid's API

  const [rowData, setRowData] = useState(); // Set rowData to Array of Objects, one Object per Row
  const [columnDefs, setCoulmnDefs] = useState ([
    {headerName: "ID", field: 'id', sortable: true, checkboxSelection: true, headerCheckboxSelection: true, flex: 5},
    {headerName: "Trimester", field: 'trimester', flex: 8},
    {headerName: "Year", field: 'year', flex: 8},
    {headerName: "Course No", field: 'course_no', flex: 10}, 
    {headerName: "Course Title", field: 'title', flex: 30},
    {headerName: "Time", field: 'time', flex: 8, cellRenderer: 'agAnimateShowChangeCellRenderer'},
    {headerName: "Credit", field: 'credit_attempted', flex: 5},
  ]);
  
  const defaultColDef = useMemo( ()=> ({
      sortable: true,  
      editable: true, 
      filter: true, 
      floatingFilter: true
    }), []);

  
  const onGridReady = (params) => {
      console.log("grid is ready")
/*
      fetch("https://jsonplaceholder.typicode.com/comments").then(resp => resp.json())
          .then(resp => {
          console.log(resp)
          params.api.applyTransaction({ add: resp }) //adding API data to grid
          })
          */
      setRowData(courses);
  }

  //define selection type single or multiple
  const rowSelectionType='multiple'
  const onSelectionChanged = (event) => {
    console.log('onRowSelectionChanged => event: ', event)
    console.log('onRowSelectionChanged => event.api.getSelectedRows(): ', 
    event.api.getSelectedRows())
  }

  /*
    useEffect(() => {
    setRowData(courses);
  }, []);
  */

  const onInsertOne = useCallback( ()=> {
    const newRecord = createOneCourseRecord();
    console.log('onInsertOne => newRecord:', newRecord)
    console.log('onInsertOne => before courses:', courses)
    courses = [newRecord, ...courses];
    console.log('onInsertOne => after courses:', courses)
    setRowData(courses);
  }, []);

  const onTxInsertOne = useCallback ( () => {
    const newRecord = createOneCourseRecord();
    const res = gridRef.current.api.applyTransaction({
      add: [newRecord],
      update: [],
      remove: []
    });
    console.log ('onTxInsertOne => res:', res)
  }, []);

  const getRowId = useCallback( params => {
    //console.log ('getRowId => params.data.id:', params.data.id)
    return params.data.id;
  }, []);

  const onRemove = useCallback (() => {
    const selectedNodes 
      = gridRef.current.api.getSelectedNodes();
    console.log ("onRemove => selectedNodes: ", selectedNodes)
    const selectedIds = selectedNodes.map (
      node => node.data.id);
    console.log ("onRemove => selectedIds: ", selectedIds)
    courses = courses.filter (
      course => selectedIds.indexOf(course.id) < 0
    );
    console.log ("onRemove => courses: ", courses)
    setRowData(courses);
  }, []);

  const onReverse = useCallback (() => {
    courses = [...courses].reverse();
    setRowData(courses);
  }, []);

  const onTxRemove = useCallback (() => {
    const selectedNodes 
      = gridRef.current.api.getSelectedNodes();
    console.log ("onRemove => selectedNodes: ", selectedNodes)
    const selectedData = selectedNodes.map (
      node => node.data);
    console.log ("onRemove => selectedData: ", selectedData)
    gridRef.current.api.applyTransaction ({remove: selectedData});
  }, []);

  const onUpdate = useCallback (() => {
    console.log ('onUpdate => before courses: ', courses);
    courses = courses.map (course => {
      console.log ('onUpdate => Math.random(): ', Math.random());
      if (Math.random() > 0.5) { return course; }
      course.time = "Sun 1-5pm"
      console.log ('onUpdate => course.time : ', course.time );
      return course
    });
    console.log ('onUpdate => after courses: ', courses);
    setRowData(courses);
  }, []);

  const onTxUpdate = useCallback (() => {
    const updateRecords = [];
    gridRef.current.api.forEachNode (node => {
      if (Math.random() > 0.5) { return; }
      const course = node.data;
      console.log ('onTxUpdate => course: ', course);
      course.time = "Sun 1-5pm"
      updateRecords.push(course)
    });
    gridRef.current.api.applyTransaction ({update: updateRecords});
  }, []);

  return (
    <div>
      <div className="search">
        <h2>Find by Name, Date of Birth, or Student ID</h2>
        <hr></hr>
        <form>
            <label>First Name: </label>
            <input type="text"
            />
            <label>Last Name: </label>
            <input type="text"
            />
            <label>Date of Birth: </label>
            <input type="text"
            />
            <label>Student ID: </label>
            <input type="text"
            />
        </form>
      </div>
            <button onClick={onInsertOne}>Start</button>
            <button onClick={onReverse}>Save</button>
      <hr></hr>
      {/* On div wrapping Grid a) specify theme CSS Class Class and b) sets Grid size */}
      <div className="ag-theme-alpine" style={{width: 1200, height: 750}}>
        <AgGridReact
            ref={ gridRef } // Ref for accessing Grid's API
            asyncTransactionWaitMillis={5000}
            //enableCellChangeFlash = {true}
            getRowId={ getRowId }
            rowData={ rowData } // Row Data for Rows
            columnDefs = { columnDefs } // Column Defs for Columns
            defaultColDef={ defaultColDef } // Default Column Properties
            onGridReady={onGridReady}
            rowSelection={rowSelectionType}
            onSelectionChanged={onSelectionChanged}
            rowMultiSelectWithClick={true} 
            animateRows={ true } // Optional - set to 'true' to have rows animate when sorted
            //rowSelection='multiple' // Options - allows click selection of rows
            />
      </div>
    </div>
  );
}

export default Find;