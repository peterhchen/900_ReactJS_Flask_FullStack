"""
Description:
    module for read/write
    12/22/2022 Created by Peter Hanping Chen
"""
import os
import json
import pandas as pd
import openpyxl
from openpyxl_image_loader import SheetImageLoader

class StudentInfo():
    """
    Student Information
    """
    def __init__(self, reg_year, reg_id, reg_name):
        self.reg_year = reg_year
        self.reg_id = reg_id
        self.reg_name = reg_name

    def __str__(self):
        return f'year: {self.reg_year}'
    def __repr__(self):
        return f'year: {self.reg_year}'

class CourseInfo ():
    """
    Course Information
    """
    def __init__(self, trimester_year, course_id, course_title, credit_attempt):
        self.trimester_year = trimester_year
        self.trimester = '' # year will be filled later on
        self.year = ''      # trimester will be filled later on
        self.course_id = course_id
        self.course_title = course_title
        self.credit_attempt = credit_attempt
        self.credit_earn = 0
        self.course_grade = ''
        self.course_point = 0.0
    def __str__(self):
        return f'year: {self.trimester_year}, c_id: {self.course_id}'
    def __repr__(self):
        return f'year: {self.trimester_year}, c_id: {self.course_id}'

class TrimesterInfo (CourseInfo):
    """
    Trimester (tm) Course Information
    """
    def __init__(self, trimester_year, course_id, course_title, credit_attempt):
        CourseInfo.__init__(self, trimester_year, course_id, course_title, credit_attempt)
        self.trimester_year = trimester_year # year will be filled later on
        self.course_id = course_id
        self.credit_attempt = credit_attempt
        self.credit_earn = 0
        self.course_grade = ''
        self.course_point = 0.0
        self.tm_course_cnt = 0
        self.tm_credit_attempt = 0
        self.tm_credit_earn = 0
        self.tm_grade = 0.0
        self.tm_point = 0.0
        self.cm_credit_attempt = 0
        self.cm_credit_earn = 0
        self.cm_grade = 0.0
        self.cm_point = 0.0
    def __str__(self):
        new_line = '\n'
        return f'{new_line} str ty: {self.trimester_year}, \
tm_id: {self.course_id}, \
tm_earn: {self.tm_credit_earn}, tm_course_cnt {self.tm_course_cnt}, \
tm_pt: {self.tm_point}, tm_grade: {self.tm_grade}, \
cumu_earn: {self.cm_credit_earn}, \
cumu_pt: {self.cm_point}, cumu_grade: {self.cm_grade}'
    def __repr__(self):
        new_line = '\n'
        return f'{new_line}repr ty: {self.trimester_year}, \
tm_id: {self.course_id}, \
tm_earn: {self.tm_credit_earn}, tm_course_cnt {self.tm_course_cnt}, \
tm_pt: {self.tm_point}, tm_grade: {self.tm_grade}, \
cumu_earn: {self.cm_credit_earn}, \
cumu_pt: {self.cm_point}, cumu_grade: {self.cm_grade}'

class TransferInfo ():
    """
    Course Information
    """
    def __init__(self, year, course_id, course_title, credit_earn):
        self.year = year
        self.course_id = course_id
        self.course_title = course_title
        self.credit_earn = credit_earn  # 3
        self.course_grade = 'TR'  # 'TR'
        self.total_transfer_credit = 0
    def __str__(self):
        return f'year: {self.year}'
    def __repr__(self):
        return f'course_dir: {self.year}'

class ReadReg ():
    """
    Description:
    Read Register/Transfer information
    """
    def __init__(self):
        self.reg_fn = ''
        self.header_kw = \
            ["STUDENT ID", "NAME", "DEGREE", "MAJOR", "Date of Birth", \
            "Date of Attend"]
        self.course_id_kw = "COURSE ID"
        self.trimester_year_kw = "TRIMESTER YEAR"
        self.transfer_year_kw = "TRANSFER YEAR"
        # self.transfer_dir_kw = "TRANSFER DIRECOTRY"

    @staticmethod
    def extract_photo(reg_fn):
        """
        Extract Student Photo Image and sabe into register.jpg.
        """
        #loading the Excel File and the sheet
        pxl_doc = openpyxl.load_workbook(reg_fn)
        sheet = pxl_doc['Sheet1']
        #calling the image_loader
        image_loader = SheetImageLoader(sheet)
        #get the image (put the cell you need instead of 'A1')
        image = image_loader.get('B1')
        path = os.path.dirname(os.path.abspath(reg_fn))
        image_name = os.path.join(path, 'register.jpg')
        # print('image_name: ', image_name)
        image.save(image_name)

    @staticmethod
    def read_header(reg_fn, reg_lines):
        """
        1. Extract Student Photo Image
        2. Read header information
        """
        r_r = ReadReg()
        r_r.extract_photo(reg_fn)
        reg_eles = []
        r_r = ReadReg()
        header_info = []
        i = 0
        for reg_line in reg_lines:
            reg_eles = reg_line.split(';')
            #print('reg_eles:', reg_eles)
            # reg_eles: ['STUDENT ID', '1503011365', 'Unnamed: 2']
            # reg_eles: ['NAME', 'SOHAN BHARGAV KEESARA', '']
            for reg_ele in reg_eles:
                #print('reg_ele:', reg_ele)
                # reg_ele: STUDENT ID
                # reg_ele: 1503011365
                # reg_ele: Unnamed: 2

                j = 0
                for header_ele in r_r.header_kw:
                    #print('reg_line:', reg_line)
                    #print('header_ele:', header_ele)
                    if reg_ele == header_ele:
                        # print('header_ele:', header_ele)
                        ele_dict = '{"' + reg_ele + '": "' + reg_eles[j+1] + '"}'
                        if ele_dict not in header_info:
                            header_info.append(ele_dict)
                            #print('header_info:', header_info)
                        j += 1
                        continue
            i += 1
        return header_info

    @staticmethod
    def read_register(reg_lines):
        """
        Read register information
        """

        reg_eles = []
        r_r = ReadReg()
        trimester_flag = False
        trimester_year = ""
        c_i = []
        i = 0
        for reg_line in reg_lines:
            reg_eles = reg_line.split(';')
            # print('read_register () => reg_eles:', reg_eles)
            # reg_eles: ['STUDENT ID', '1503011365', 'Unnamed: 2']
            # reg_eles: ['NAME', 'SOHAN BHARGAV KEESARA', '']
            # ['TRIMESTER YEAR', 'Fall, 2015', '']
            # ...
            # ['TRIMESTER YEAR', 'Fall, 2015', ''
            # ['CE450', 'Computer Architecture I', '../course_grade/2015/CS530_simon.xlsx']
            # ['CS440', 'Computer Network I', '../course_grade/2015/CSS440_jerry.xlsx']
            # ['CS596-012', 'SP: XML and Application', '../course_grade/2015/CS596-012_peter.xlsx']
            # ...
            # ['TRIMESTER YEAR', 'Fall, 2016', '']  <=== Stop reading when TRANSFER YEAR
            j = 0
            for reg_ele in reg_eles:
                if reg_ele == r_r.course_id_kw:
                    i += 1
                    break
                if reg_ele == r_r.transfer_year_kw:
                    trimester_flag = False
                    break
                if reg_ele == r_r.trimester_year_kw:   # <=== set trimester_flag to True
                    trimester_year = reg_eles[j+1]  # trimester year
                    trimester_flag = True
                    j += 1
                    i += 1
                    break
                if trimester_flag is True:    # <=== Startt reading in trimseter section
                    #print('read_register () => reg_eles:', reg_eles)
                    #c_i.append(CourseInfo("2015", "CS550", "Computer xxx", "3.0"))
                    #print('reg_eles[0]:', reg_eles[0]) # Course ID
                    #print('reg_eles[1]:', reg_eles[1]) # course Title
                    #print('reg_eles[2]:', reg_eles[2]) # credit attempted = 3
                    #print('reg_eles:', reg_eles)
                    c_i.append (CourseInfo (trimester_year, reg_eles[0], reg_eles[1], \
                        int(reg_eles[2])))
                    i += 1
                    break
        return c_i

    @staticmethod
    def read_transfer(reg_lines):
        """
        Read transfer information
        """
        r_r = ReadReg()
        reg_eles = []
        transfer_flag = False
        transfer_year = ""
        txf_i = []
        i = 0
        for reg_line in reg_lines:
            reg_eles = reg_line.split(';')
            #print('reg_eles:', reg_eles)
            # reg_eles: ['STUDENT ID', '1503011365', 'Unnamed: 2']
            # reg_eles: ['NAME', 'SOHAN BHARGAV KEESARA', '']
            for reg_ele in reg_eles:
                if reg_ele == r_r.transfer_year_kw:
                    transfer_flag = True
                    # print('rw.transfer_year_kw => reg_ele:', reg_ele)
                    transfer_year = reg_eles[1]
                    i += 1
                    break
                if transfer_flag is True:
                    #print('transfer_year:', transfer_year, ', course_id:', reg_eles[0], \
                    #', course_tile:', reg_eles[1], ', credit attemped:', reg_eles[2], \
                    #    ', credit earned:', reg_eles[3])
                    txf_i.append (TransferInfo (transfer_year, reg_eles[0], reg_eles[1], \
                        reg_eles[3]))
                    i += 1
                    break
        return txf_i

    @staticmethod
    def read_excel2text(reg_fn):
        """
        Read register information.
        """
        # print('read_excel2text() => reg_fn:', reg_fn)
        d_f = pd.read_excel(reg_fn)
        d_f_csv = d_f.to_csv(index = False, sep =';')
        #print('d_f_csv:')
        #print(d_f_csv)
        reg_lines = d_f_csv.splitlines()
        #print('reg_lines:', reg_lines)
        r_r = ReadReg()
        header_info = []
        header_info = r_r.read_header(reg_fn, reg_lines)
        #print('header_info:', header_info)
        #r_r.set_student_info(header_info)
        course_info = []
        course_info = r_r.read_register(reg_lines)
        #print('course_info:', course_info)
        transfer_info = []
        transfer_info = r_r.read_transfer(reg_lines)
        #print('transfer_info', transfer_info)
        return header_info, course_info, transfer_info

    @staticmethod
    def get_reg_id(header_info):
        """
        Get register ID
        # header_info:
        # ['{"STUDENT ID": "1503011365"}', '{"NAME": "SOHAN BHARGAV KEESARA"}',
        # '{"DEGREE": "MASTER OF COMPUTER SCIENCE"}', '{"MAJOR": "COMPUTER SCIENCE"}',
        # '{"Date of Birth": "03-05-1993"}', '{"Date of Attend": "2015-09-01 00:00:00"}']
        """
        reg_dict = header_info[0]
        # '{"STUDENT ID": "1503011365"}'
        _, reg_id = reg_dict.split(':')
        # "1503011365"}
        reg_id = reg_id.replace('}', "")
        return reg_id

    @classmethod
    def print_header_info(cls, header_info):
        """
        Print student basic information (header_info)
        """
        print('************************************************************************************\
********************************************************')
        print('header_info:')
        for header_line in header_info:
            header_json = json.loads(header_line)
            for key, value in header_json.items():
                print(f"{key + ': ':<20}{value:<20}")
        # ['{"STUDENT ID": "1503011365"}', '{"NAME": "SOHAN BHARGAV KEESARA"}',
        # '{"DEGREE": "MASTER OF COMPUTER SCIENCE"}', '{"MAJOR": "COMPUTER SCIENCE"}',
        # '{"Date of Birth": "03-05-1993"}', '{"Date of Attend": "2015-09-01 00:00:00"}']
        print('************************************************************************************\
********************************************************')
