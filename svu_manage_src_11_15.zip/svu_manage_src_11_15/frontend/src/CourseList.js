const CourseList = ({ courses, title, handleDelete }) => {
    //const title = props.title;
    // How to delete course with ID?
    // We should use const [courses, setCourses] = useState()
    // We get the function handle and invoked in the parent component.
    // const handleDelete = (id) => {
    // } 
    console.log(courses)
    return (  
        <div className="course-list">
            <h2> { title } </h2>
            {courses.map((course) => (
                <div className="course-preview" key = {course.id} >
                   <p>{course.page} &emsp; {course.trimester} &emsp; {course.course_no} &emsp; {course.title} &emsp; 
                   { course.credit_attempted } &emsp; {course.credit_earned} &emsp; 
                   {course.grade } &emsp; {course.points }</p>
                   <button onClick = {() => handleDelete (course.id)} > delete course</button>
                </div>
            ))}
        </div>
    );
}
 
export default CourseList;