""""
Usage:
# run python3 auto_grade.py with options
> python3 auto_grade.py \
>  reg_fn = "../reg_trans/2015/1503011365/register.xlsx" \
>  c_dir = "../course_grade"
input parameter:
reg_trans_fn: register and transcript
Create by Peter Hanping Chen (12/11/2022) peter.hp.chen@gmail.com
"""
import sys
import cmd_proc
import read_reg
import read_grade
import write_trans

if __name__ == '__main__':
    # print("sys.argv:", sys.argv)
    c_info = cmd_proc.CmdProc()
    reg_fn, c_dir = c_info.cmd_proc(sys.argv)
    r_r = read_reg.ReadReg()
    header_info, course_info, transfer_info = r_r.read_excel2text(reg_fn)
    r_r.print_header_info(header_info)

    reg_id = r_r.get_reg_id (header_info)
    reg_id = reg_id.replace('"', "").strip()

    # print course_info (register information)
    #r_g.print_course_info(course_info)

    # get course grade, credit_earn, and point for course_info
    r_g = read_grade.ReadGrade()
    c_trimester_year_list, course_info = r_g.get_grade_credit_point(reg_id, c_dir, course_info)

    print('Transcript:')
    tm_cm_info, tm_total_credit_earn, tm_total_gpa, cm_total_credit_earn, cm_total_gpa = \
        r_g.calc_grade_credit(c_trimester_year_list, course_info)

    # Print course info
    r_g.print_course_tm_cm_info(c_trimester_year_list, tm_cm_info)
    # Transfer transfer_info
    transfer_credit = r_g.calc_print_transfer_credit(transfer_info)
    # print summary: total transfer, total cumulative credit, gpa
    r_g.print_summary(transfer_credit, cm_total_credit_earn, cm_total_gpa)

    w_t = write_trans.WriteTrans()
    w_t.write_excel_trans(reg_fn, header_info, c_trimester_year_list, tm_cm_info, transfer_info, \
        transfer_credit, cm_total_credit_earn, cm_total_gpa)
