import { Link } from 'react-router-dom';
const title = "SVU Management System";
const Navbar = () => {
    return ( 
        <nav className="navbar">
            <h1>{ title }</h1>
            <div className="links">  
                <Link to="/course">Course</Link>
                <Link to="/register">Registration</Link> 
                <Link to="/transcript">Transcript</Link>
                {/* <Link to="/transcriptDetails">Transcript-Details</Link> */}
                <Link to="/search">Search</Link>
                <Link to="/popup">Popup</Link>
                <Link to="/select">Select</Link>
                <Link to="/directory">Directory</Link>
                <Link to="/rowselection">Row-Selection</Link>
                <Link to="/rowdataex">Row-Data-Ex</Link>
            </div>
        </nav> 
    );
}
 
export default Navbar;