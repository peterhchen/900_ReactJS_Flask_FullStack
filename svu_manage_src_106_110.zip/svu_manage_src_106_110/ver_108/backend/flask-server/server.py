from flask import Flask
# CORS (Cross Origin Resource Sharing)
# Allow server (flask) to cross any orgins (domain, scheme, or port).
# https://www.youtube.com/watch?v=tPKyDM0qEB8
# > pip install flask-cors
from flask_cors import CORS
from flask import request
import os
import json

app = Flask (__name__)
CORS(app)  # make every URL endpoint allowed cross origin

# https://www.youtube.com/watch?v=e9jXngbW1RM
# https://www.geeksforgeeks.org/python-using-2d-arrays-lists-the-right-way/

class Student:
    def __init__ (self, student_id, name, fname, lname, dob, adm_year, adm_trimester, gpa):
        self.student_id = student_id
        self.name = name
        self.fname = fname
        self.lname = lname
        self.dob = dob
        self.adm_year = adm_year
        self.adm_trimester = adm_trimester
        self.gpa = gpa

class Course:
    def __init__ (self, course_id, course_year, course_trimester, course_no, course_title, credit_attempted, creadit_earned, grade, points):
        self.course_id = course_id
        self.course_year = course_year
        self.course_trimester = course_trimester
        self.course_no = course_no
        self.course_title = course_title
        self.credit_attempted = credit_attempted
        self.credt_earned = creadit_earned
        self.grade = grade
        self.points = points

# API Route
@app.route ("/search", methods=["GET", "POST"])
def search():
    student_id = request.args.get ('STUDENT_ID')
    fname = request.args.get('FNAME')
    lname = request.args.get('LNAME')
    dob = request.args.get('DOB')
    cmd = request.args.get('CMD')
    name = fname + lname
    print("Flask => STUDENT_ID:", student_id)
    print("Flask => Name:", fname)
    print("Flask => Name:", lname)
    print("Flask => DOB:", dob)
    print("Flask => CMD:", cmd)

    # student_id, name, fname, lname, dob, adm_year, adm_trimester, gpa):
    transcript = []
    # Assume, we have two student with same name and each take 12 courses.
    num_student, num_course = 1000, 30
    adm_year = '2023'
    adm_trimester = 'Fall'
    id = '1502011365'
    # student = Student(student_id, name, fname, lname, dob, adm_year, adm_trimester, '')
    fn = id + '.json'
    path_fn = os.path.join ('./svu_data/transcript', adm_year, id, fn)
    print('path_fn:', path_fn)
    with open (path_fn) as s_file:
        json_data = json.load(s_file)
        print('json_data:', json_data)
    
    return json_data
    """
    return {
        "kw": "1503011365; SOHAN BHARGAV KEESARA; 03-05-1993",
        "student_id": "1503011365", 
        "name": "SOHAN BHARGAV KEESARA",
        "DOB": "03-05-1993",
        "course": [
        {
            "id": 1, "trimester": "Transfer", "year": 2015, "course_no": "EE220", "title": "RFIC Design I",
            "credit_attempted": "TR", "credit_earned": 3, "grade": "TR", "points": "TR"
        },
        {
            "id": 2, "trimester": "Transfer", "year": 2015, "course_no": "EE250", "title": "Prob Ran Vari & St P",
            "credit_attempted": "TR", "credit_earned": 3, "grade": "TR", "points": "TR"
        }]
    }
    """

@app.route ("/course")
def create():
    return {
        "course": [
        {
            "id": 0, "trimester": "Fall", "year": 2023, "course_no": "CS450", "title": "Computer Architecture I", 
            "time": "Mon 6-9pm", "credit_attempted": 3
        },
        {
            "id": 1, "trimester": "Fall", "year": 2023, "course_no": "CS440", "title": "Computer Networks I",
            "time": "Tue 6-9pm", "credit_attempted": 3
        },
        {
            "id": 2, "trimester": "Fall", "year": 2023, "course_no": "CS500", "title": "Operating System Design",
            "time": "Wed 6-9pm", "credit_attempted": 3
        },
        {
            "id": 3, "trimester": "Fall", "year": 2023, "course_no": "CS520", "title": "Database System Design",
            "time": "Thu 6-9pm", "credit_attempted": 3
        },
        {
            "id": 4, "trimester": "Fall", "year": 2023, "course_no": "CS540", "title": "Computer Networks II",
            "time": "Fri 6-9pm", "credit_attempted": 3
        },
        {
            "id": 5, "trimester": "Fall", "year": 2023, "course_no": "CS502", "title": "Design and Analysis of Algorithm",
            "time": "Sat 6-9pm", "credit_attempted": 3 
        },
        {
            "id": 6, "trimester": "Fall", "year": 2023, "course_no": "CS596-003", "title": "SP: Data Pipeline: Apache Airflow",
            "time": "Mon 6-9pm", "credit_attempted": 3
        },
        {
            "id": 7, "trimester": "Fall", "year": 2023, "course_no": "CS596-005", "title": "SP: Machine Learning: Scikit-learn",
            "time": "Tue 6-9pm", "credit_attempted": 3
        },
        {
            "id": 8, "trimester": "Fall", "year": 2023, "course_no": "CS596-007", "title": "SP: Deep Learning: PyTorch, Tensoflow, and Keras",
            "time": "Wed 6-9pm", "credit_attempted": 3
        },
        {
            "id": 9, "trimester": "Fall", "year": 2023, "course_no": "CS596-009", "title": "SP: Reinforcement Learning: OpenAI and PyTorch",
            "time": "Thu 6-9pm", "credit_attempted": 3
        },
        {
            "id": 10, "trimester": "Fall", "year": 2023, "course_no": "CS596-011", "title": "SP: Full Stack Development: ReactJS, Python, and Flask",
            "time": "Fri 6-9pm", "credit_attempted": 3
        },
        {
            "id": 11, "trimester": "Fall", "year": 2023, "course_no": "CS596-026", "title": "SP: OpenStack: Build Private Cloud",
            "time": "Sat 6-9pm", "credit_attempted": 3
        },
        {
            "id": 12, "trimester": "Fall", "year": 2023, "course_no": "CS596-027", "title": "SP: Software Defined Networking",
            "time": "Mon 6-9pm", "credit_attempted": 3
        },
        {
            "id": 13, "trimester": "Fall", "year": 2023, "course_no": "CS596-028", "title": "SP: Hadoop and Big Data: Manage Cloud by Kafka, Spark, Flume, Zookeeper, HDFS",
            "time": "Tue 6-9pm", "credit_attempted": 3
        },
        {
            "id": 14, "trimester": "Fall", "year": 2023, "course_no": "CS596-039", "title": "SP: Web Applicaiton Testing: Selenium, Docker, CI/CD",
            "time": "Wed 6-9pm", "credit_attempted": 3
        },
        {   
            "id": 15, "trimester": "Fall", "year": 2023, "course_no": "CS596-041", "title": "SP: High Performace Networks",
            "time": "Thu 6-9pm", "credit_attempted": 3
        }
        ]
    }

# API Route
@app.route ("/transcript")
def transcript():
    transcript = []
    student = Student()
    transcript.append(student(''))
    return {
        "kw": "1503011365; SOHAN BHARGAV KEESARA; 03-05-1993",
        "ID": "1503011365", 
        "name": "SOHAN BHARGAV KEESARA",
        "DOB": "03-05-1993",
        "transcript": [
        {
            "trimester": "Transfer", "year": 2015, "course_no": "EE220", "title": "RFIC Design I",
            "credit_attempted": "TR", "credit_earned": 3, "grade": "TR", "points": "TR",
            "tid": 1
        },
        {
            "trimester": "Transfer", "year": 2015, "course_no": "EE250", "title": "Prob Ran Vari & St P",
            "credit_attempted": "TR", "credit_earned": 3, "grade": "TR", "points": "TR",
            "tid": 2
        }]
    }


@app.route ("/rowdataex", methods=["GET", "POST"])
def url_param_rowdata():
    student_ID = request.args.get ('STUDENT_ID')
    name = request.args.get('Name')
    dob = request.args.get('DOB')
    print("Flask => STUDENT_ID:", student_ID)
    print("Flask => Name:", name)
    print("Flask => DOB:", dob)
    return {"STUDENT_ID": student_ID, "Name": name, "DOB": dob }
    
if __name__ == "__main__":
    app.run(debug = True)