import React, { useState, useRef, useEffect, useMemo, useCallback } from 'react';
import { render } from 'react-dom';
import { AgGridReact } from 'ag-grid-react'; // the AG Grid React Component
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS

const Create = () => {
  const [error, setError] = useState(null);
  const gridRef = useRef(); // Optional - for accessing Grid's API
  const [data, setData] = useState(); // Set rowData to Array of Objects, one Object per Row

  const columns = [
    {headerName: "Trimester", field: 'trimester', sortable: true,  editable: true, filter: true},
    {headerName: "Year", field: 'year', sortable: true, editable: true, filter: true},
    {headerName: "Course No", field: 'course_no', sortable: true, editable: true, filter: true}, 
    {headerName: "Title", field: 'title', sortable: true, editable: true, filter: true},
    {headerName: "Create Attempted", field: 'credit_attempted', sortable: false, editable: false, filter: true},
    {headerName: "Course ID", field: 'cid', sortable: true, editable: true, filter: true}
  ];

  // DefaultColDef sets props common to all Columns
  const defaultColDef = useMemo( ()=> ({
      sortable: true
    }));

  // Example of consuming Grid Event
  const cellClickedListener = useCallback( event => {
    console.log('cellClicked', event);
  }, []);

  // Example load data from sever
  useEffect(() => {
    fetch('/create')
    .then(res => {
      console.log('Create => res: ', res)
      if (!res.ok) {
          throw Error ('Could not fetch the data for resource Create Course') 
      }
      return res.json();
    })
    .then(data => {
      console.log('create => rowData', data.create);
      setData(data.create);
    })
    .catch (err => { 
      console.log(err.message)
      setError(err.message);
    })
  }, []);

  // Example using Grid's API
  const buttonListener = useCallback( e => {
    gridRef.current.api.deselectAll();
  }, []);

  return (
    <div>
      {/* Example using Grid's API */}
      <button onClick={buttonListener}>Push Me</button>
      {/* On div wrapping Grid a) specify theme CSS Class Class and b) sets Grid size */}
      <div className="ag-theme-alpine" style={{width: 1200, height: 750}}>
        <AgGridReact
            ref={gridRef} // Ref for accessing Grid's API
            rowData={ data } // Row Data for Rows
            columnDefs = { columns } // Column Defs for Columns
            defaultColDef={defaultColDef} // Default Column Properties
            animateRows={true} // Optional - set to 'true' to have rows animate when sorted
            rowSelection='multiple' // Options - allows click selection of rows
            onCellClicked={cellClickedListener} // Optional - registering for Grid Event
            />
      </div>
    </div>
  );
}

export default Create;