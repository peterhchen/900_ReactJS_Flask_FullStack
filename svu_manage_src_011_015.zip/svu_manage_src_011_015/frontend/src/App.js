import Navbar from './Navbar';
import Transcript from './Transcript';

function App() {
  return (
    <div className="App">
      <Navbar />
      <div className="content">
        <Transcript />
      </div>
    </div>
  );
}

export default App;
