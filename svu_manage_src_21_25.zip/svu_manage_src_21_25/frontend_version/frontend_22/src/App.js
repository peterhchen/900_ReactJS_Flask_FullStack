import Navbar from './Navbar';
import Transcript from './Transcript';
import Create from './Create';

// https://stackoverflow.com/questions/63124161/
// attempted-import-error-switch-is-not-exported-from-react-router-dom
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';

function App() {
  return (
    <div className="App">
      <Navbar />
      <div className="content">
        <Router>
          <Routes>
            <Route exact path ="/" element={ <Transcript /> } />
            <Route path ="/create" element={ <Create /> } />
          </Routes>
        </Router>
      </div>
    </div>

  );
}

export default App;
