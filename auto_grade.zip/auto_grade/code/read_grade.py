"""
Read Grade
12/28/2022 created by Peter Hanping Chen
"""
import os
import sys
import read_reg

class ReadGrade():
    """
    Read Grade
    """
    def __init__(self):
        self.grade_path = ""
        self.scr_fn = ""
        self.course_id = []
        self.course_date = []
        self.course_grade = []
        self.transfer_flag = False

    @staticmethod
    def get_trimester_year (trimester_year):
        """
        Get register date
        # course info:
        # trimester_year: Fall, 2015 , id: CE450 , title: Computer Architecture I , grade:
        # trimester_year: Fall, 2015 , id: CS440 , title: Computer Network I , grade:
        # trimester_year: Fall, 2015 , id: CS596-012 , title: SP: XML and Application , grade:
        # trimester_year: Spring, 2016 , id: CS500 , title: Operating System Design , grade:
        # trimester_year: Spring, 2016 , id: CS520 , title: Database System Principles , grade:
        # trimester_year: Spring, 2016 , id: CS596-026 ,
        # title: SP: Open-Stack Cloud Architecture , grade:
        # trimester_year: Summer, 2016 , id: CS540 , title: Computer Network II , grade:
        # trimester_year: Summer, 2016 , id: CS596-027 ,
        # title: SP: Software Defined Network , grade:
        # trimester_year: Summer, 2016 , id: CS596-039 ,
        # title: SP: Web Application Testing , grade:
        """
        # trimester_year: Fall, 2015
        c_trimester, c_year = trimester_year.split(',')
        return c_trimester.strip(), c_year.strip()

    def get_grade_path (self, c_dir, c_year, c_trimester):
        """
        Set/Get grade path
        c_trimester, c_year
        # Fall, 2015
        """
        self.grade_path = os.path.join(c_dir, c_year, c_trimester)
        # print('self.grade_path:', self.grade_path)
        # course_grade/2015/Fall/*.csv
        return self.grade_path

    def get_csv_grade(self, grade_fn, reg_id, c_dir, year, trimester):
        """
        Get Grade for register ID
        """
        path = self.get_grade_path(c_dir, year, trimester)
        cmd = "grep " + reg_id + " " + path + "/*.csv >> " + grade_fn
        # print("get_csv_grade() => cmd:", cmd)
        os.system(cmd)

    @staticmethod
    def get_id_all_grade (grade_fn):
        """
        Given grade_fn ("ID.grd"), get all grades from the student ID.
        """
        grade_lines = []
        with open (grade_fn, "r", encoding='utf-8') as f_i:
            lines = f_i.readlines()
        for line in lines:
            grade_lines.append(line.replace('\n', ''))
        return grade_lines

    @staticmethod
    def xlsx2grade(path, c_year, c_trimester, reg_id):
        """
        RUn Script to grep the grade
        """
        cmd = "rm " + path + "/*.csv"
        os.system(cmd)
        reg_id = reg_id.replace('"', "").strip()
        f_n_txt = reg_id + ".txt"
        cmd = "ls " + path + "/*.xlsx > " + "./" + f_n_txt
        #print("ls cmd:", cmd)
        os.system(cmd)
        f_list = []
        #print('f_n:', f_n)
        with open(f_n_txt, "r", encoding='utf-8') as f_i:
            for f_line in f_i:
                line_xlsx = os.path.basename (f_line).replace('\n', "")
                # CS440_jerry.xlsx
                line_csv = line_xlsx.replace('xlsx', "csv")
                # CS440_jerry.csv
                #print('line_csv:', line_csv)
                new_line = "ssconvert " + os.path.join(path, line_xlsx) + ' ' + \
                    os.path.join(path, line_csv)
                f_list.append(new_line)
        #print('f_list:', f_list)
        # ['ssconvert ../course_grade/2015/Fall/CS440_jerry.xlsx
        # ../course_grade/2015/Fall/CS440_jerry.csv', ...]
        # Clean up txt.
        cmd = "rm " + f_n_txt
        os.system(cmd)
        f_n_scr = c_year + '_' + c_trimester + '_' + reg_id + '.scr'
        #print('f_n_scr:', f_n_scr)
        # f_n_scr: 2015_Fall_1503011365.scr
        # f_n_scr: 2016_Spring_1503011365.scr
        # f_n_scr: 2016_Summer_1503011365.scr
        # f_n_scr: 2016_Fall_1503011365.scr
        with open(f_n_scr, "w", encoding='utf-8') as f_o:
            for f_line in f_list:
                f_o.write(f_line + '\n')
        # ssconvert ../course_grade/2015/Fall/CS440_jerry.xlsx
        # ../course_grade/2015/Fall/CS440_jerry.csv
        cmd = "chmod 744 " + f_n_scr
        os.system(cmd)
        # Run scr file
        cmd = "./" + f_n_scr + " > /dev/null 2>&1"
        # print('cmd:', cmd)
        # print('tranlating xlsx files into csv files ...:', f_n_scr)
        os.system(cmd)
        # Clean up script.
        cmd = "rm ./" + f_n_scr
        os.system(cmd)
        # ./1503101365.scr
        # Clean up run script
        #cmd = 'rm *.scr; rm *.txt'
        #os.system(cmd)

    def convert_xlsx2csv(self, reg_id, c_dir, c_trimester_year):
        """
        Convert all xlsx into csv format.
        # > apt-get install gnumeric
        convert xlsx into csv formt
        > ssconvert CS440_jerry.xlsx  CS440_jerr7.csv
        """
        c_trimester, c_year = c_trimester_year.split(',')
        c_trimester = c_trimester.strip()
        c_year = c_year.strip()
        path = self.get_grade_path(c_dir, c_year.strip(), c_trimester.strip())
        #print('path:', path)
        r_r = ReadGrade()
        r_r.xlsx2grade(path, c_year, c_trimester, reg_id)

    def gen_course_grade(self, grade_fn, c_dir, reg_id, year, trimester):
        """
        Generate Grade for register ID ("reg_id.grd")
        """
        # grep grade into id.grd
        #print('get_course_grade => c_dir:', c_dir, 'year:', year, 'trimester:', trimester)
        self.get_csv_grade (grade_fn, reg_id, c_dir, year, trimester)
        # reg_id_fn = reg_id + ".grd"
        # ./1503101365.grd
        # Clean up run grade file
        #cmd = 'rm ' + reg_id_fn
        #os.system(cmd)

    @staticmethod
    def grade2pt(grade, credit_attempt):
        """
        Letter Grade to Point translation.
        grade => credit earn and point:
        grade == ('A', 'A+'): credit_earn = credit_attempted, point = str(4.0)
        grade == 'A-': credit_earn = credit_attempted, point = str(3.7)
        grade == 'B+': credit_earn = credit_attempted, point = str(3.3)
        grade == 'B': credit_earn = credit_attempted, point = str(3.0)
        grade == 'B-': credit_earn = credit_attempted, point = str(2.7)
        grade == 'C+': credit_earn = credit_attempted, point = str(2.3)
        grade == 'C': credit_earn = credit_attempted, point = str(2.0)
        grade == 'C-': credit_earn = credit_attempted, point = str(1.7)
        grade == 'D+': credit_earn = credit_attempted, point = str(1.3)
        grade == 'D': credit_earn = credit_attempted, point = str(1.0)
        grade == 'F': credit_earn = 0.0, point = str(0.0)
        grade == 'P': credit_earn = credit_attempted, point = str(0.0)
        grade == 'TR': credit_earn = credit_attempted, point = str(0.0)
        """
        grade = grade.strip()
        point = {
            'A+': str(4.0),
            'A': str(4.0),
            'A-': str(3.7),
            'B+': str(3.3),
            'B': str(3.0),
            'B-': str(2.7),
            'C+': str(2.3),
            'C': str(2.0),
            'C-': str(1.7),
            'D+': str(1.3),
            'D': str(1.0),
            'F': str(0.0),
            'P': str(0.0),
            'TR': str(0.0)
        }.get(grade)
        if grade in ('A+', 'A', 'A-', 'B+', 'B', 'B-', 'C+', 'C', 'C-', 'D+', 'D' \
            'P', 'TR'):
            credit_earn = str(credit_attempt)
        elif grade == 'F':
            credit_earn = str(0)
        return credit_earn, point

    # @staticmethod
    def get_course_grade(self, id_all_grade, c_trimester, c_year, course_id, credit_attempt):
        """
        Given course grades given by all professor (id_all_grade),
        Find grade for each coruse ID.
        """
        r_g = ReadGrade()
        c_trimester = c_trimester.strip()
        c_year = c_year.strip()
        course_id = course_id.strip()
        course_grade = ''
        course_point = ''
        # print('get_course_grade => course_id:', course_id)
        if "TRANSFER" in course_id or "TXF" in course_id:
            self.transfer_flag = True

        all_course_grade_tokens = []
        trimester_year_course_id_found = False
        for line_grade in id_all_grade:
            self.transfer_flag = False
            # print('line_grade:', line_grade)
            line_grade_str = str(line_grade)
            # ../course_grade/2015/Fall/CS440_jerry.csv:"Fall, 2015",
            # 1503011365,"SOHAN BHARGAV KEESARA",
            # CS440,"Computer Networks I",3,B-
            # print('c_trimester:', c_trimester, 'c_year: ', c_year, 'course_id:', course_id, "end")
            if c_trimester in line_grade_str and c_year in line_grade_str \
                and course_id in line_grade_str:
                #id_grade_str = str(line_grade).replace(', ', ';')
                #print('id_grade_str:', id_grade_str)
                all_course_grade_tokens = line_grade_str.split(',')
                #print("all_course_grade_tokens:", all_course_grade_tokens)
                # all_course_grade_tokens: ['../course_grade/2015/Fall/CS450_simon.csv:"Fall',
                # ' 2015"', '1503011365',
                # '"SOHAN BHARGAV KEESARA"', 'CE450', '"Computer Architecture I"', '3', 'C']
                course_grade = all_course_grade_tokens[7]
                trimester_year_course_id_found = True
                credit_earn, course_point = r_g.grade2pt(course_grade, credit_attempt)
                #print("credit_earn:", credit_earn)
                return c_year, c_trimester, course_id, credit_earn, course_grade, course_point
        if trimester_year_course_id_found is False:
            print('Error  => trimester_year_course_id_found:', trimester_year_course_id_found)
            print('c_trimester:', c_trimester)
            print('c_year:', c_year)
            print('course_id:', course_id)
            print('id_all_grade:', id_all_grade)
            sys.exit()
        return c_year, c_trimester, course_id, credit_earn, course_grade, course_point

    def get_grade_credit_point (self, reg_id, c_dir, course_info):
        """
        get course grade, credit earn, and point.
        """
        # Convert xlsx into csv
        c_trimeter_year_list = []
        for c_ele in course_info:
            #print('2. main() => c_ele.trimester_year:', c_ele.trimester_year)
            c_trimester, c_year = self.get_trimester_year (str(c_ele.trimester_year))
            #print('  2. main() => c_trimester:', c_trimester, '; c_year :', c_year)
            if str(c_ele.trimester_year) not in c_trimeter_year_list:
                c_trimeter_year_list.append(str(c_ele.trimester_year))

        #c_dir = "../course_grade"
        grade_fn = reg_id + '.grd'
        cmd = 'rm ' + grade_fn
        os.system(cmd)
        for c_trimester_year in c_trimeter_year_list:
            # print('c_trimester_year:', c_trimester_year)
            self.convert_xlsx2csv(reg_id, c_dir, c_trimester_year)
            c_trimester, c_year = self.get_trimester_year (str(c_trimester_year))
            self.gen_course_grade(grade_fn, c_dir, reg_id, c_year, c_trimester)

        id_all_grade = []
        id_all_grade = self.get_id_all_grade(grade_fn)
        # print('course info:')
        #print('Verify => credit attempted and earn:')
        for c_ele in course_info:
            c_trimester, c_year = self.get_trimester_year (str(c_ele.trimester_year))
            #print('merge => trimester:', c_trimester, ', year:', c_year,
            # ', c_ele.course_id: ', c_ele.course_id)
            # Get course grade and assign to course_info strucgture.
            c_ele.year, c_ele.trimester, c_ele.course_id, c_ele.credit_earn, c_ele.course_grade, \
                c_ele.course_point = \
                self.get_course_grade(id_all_grade, c_trimester, c_year, c_ele.course_id, \
                    c_ele.credit_attempt)
            #print('merge => c_ele.course_id:', c_ele.course_id, \
            #    'c_ele.credit_earn:', c_ele.credit_earn, \
            #    'c_ele.course_grade:', c_ele.course_grade, \
            #    'c_ele.course_point:', c_ele.course_point)
        return c_trimeter_year_list, course_info

    @classmethod
    def print_tm_cm_info(cls, msg, trimester_year, credit_attempt, credit_earn, tm_point, tm_grade):
        """
        Print trimester/cumulative information
        """
        print("  " + msg)   # Print "Trimester:"" or "Cumulative:"
        if "cum" in msg or "Cumu" in msg:
            msg1 = "cm"
        else:
            msg1 = "tm"
        point_str = f"{tm_point:.2f}"
        grade_str = f"{tm_grade:.2f}"
        print(f"{'  trimester_year: ' + trimester_year:<31}\
{msg1 + '_credit_attempt: ' + str(credit_attempt):<24}\
{msg1 + '_credit_earn: ' + str(credit_earn):<20}\
{msg1 + '_point: ' + str(point_str):<20}\
{msg1 + '_grade: ' + str(grade_str):<15}")

        if "cum" in msg or "Cumu" in msg:
            print()

    @classmethod
    def find_max_course_cnt_in_tm (cls, c_trimester_year_list, tm_cm_info):
        """
        Find the maximum course cnt in the trimester/year.
        """
        max_course_cnt = 0
        for tm_cm in tm_cm_info:
            for trimester_year in c_trimester_year_list:
                if tm_cm.year in trimester_year and tm_cm.trimester in trimester_year:
                    if tm_cm.tm_course_cnt > max_course_cnt:
                        max_course_cnt = tm_cm.tm_course_cnt
        return max_course_cnt

    def print_course_tm_cm_info(self, c_trimester_year_list, tm_cm_info):
        """
        print tm/cm (trimester/cumulative) at specified trimester and year
        """
        # print('print Course and tm/cm (trimester/cumulative):')

        r_g = ReadGrade()
        tm_course_num = 0
        for tm_cm in tm_cm_info:
            max_course_cnt = r_g.find_max_course_cnt_in_tm (c_trimester_year_list, tm_cm_info)
            for trimester_year in c_trimester_year_list:
                if tm_cm.year in trimester_year and tm_cm.trimester in trimester_year:
                    if tm_course_num == 0:
                        print("  -------------------------------------------------------------\
--------------------------------------------------------------------------------")
                    print(f"{'  y: ' + tm_cm.year:<11}{'tm: ' + tm_cm.trimester:<12}\
{'c_id: ' + tm_cm.course_id:<17}{'c_title: ' + tm_cm.course_title:<46}\
{'credit att: ' + str(tm_cm.credit_attempt):<15}{'credit earn: ' + str(tm_cm.credit_earn):<16}\
{'grade: ' + tm_cm.course_grade:<11}{'point: ' + str(tm_cm.course_point):<9}")
                    tm_course_num += 1
                    #print('print_course_tm_cm_info => tm_course_num: ', tm_course_num)
                    #print('print_course_tm_cm_info => tm_cm.tm_course_cnt: ', tm_cm.tm_course_cnt)
                    if tm_course_num == max_course_cnt:
                        print("  -------------------------------------------------------------\
--------------------------------------------------------------------------------")
                        tm_course_num = 0
                        self.print_tm_cm_info("Trimester:", trimester_year, \
                            tm_cm.tm_credit_attempt, tm_cm.tm_credit_earn, \
                            tm_cm.tm_point, tm_cm.tm_grade)
                        self.print_tm_cm_info("Cumulative:", trimester_year, \
                            tm_cm.cm_credit_attempt, tm_cm.tm_credit_earn, \
                            tm_cm.cm_point, tm_cm.cm_grade)

    @classmethod
    def calc_grade_credit(cls, c_trimeter_year_list, course_info):
        """
        Calculate the trimester (tm) total grade and totoal credit
        """
        tm_cm_info = []
        cm_total_credit_attempt = 0
        cm_total_credit_earn = 0
        cm_total_point = 0.0
        cm_total_gpa = 0.0
        tm_course_num = 0
        for trimester_year in c_trimeter_year_list:
            tm_total_credit_attempt = 0
            tm_total_credit_earn = 0
            tm_total_point = 0.0
            tm_total_gpa = 0.0
            tm_total_course_cnt = 0
            for c_ele in course_info:
                if c_ele.year in trimester_year and c_ele.trimester in trimester_year:
                    #print("calc_grade_credit => c_ele.course_id:", c_ele.course_id)
                    #print("calc_grade_credit => c_ele.course_title:", c_ele.course_title)
                    tm_cm_ele = read_reg.TrimesterInfo(trimester_year, c_ele.course_id, \
                        c_ele.course_title, c_ele.credit_attempt)
                    if tm_course_num == 0:
                        tm_total_credit_attempt = 0
                        tm_total_credit_earn = 0
                        tm_total_point = 0.0
                    tm_cm_ele.year = c_ele.year
                    tm_cm_ele.trimester = c_ele.trimester
                    tm_cm_ele.course_id = c_ele.course_id
                    tm_cm_ele.course_title = c_ele.course_title
                    tm_cm_ele.course_grade = c_ele.course_grade
                    tm_cm_ele.course_point = c_ele.course_point
                    tm_total_credit_attempt += int(c_ele.credit_attempt)
                    cm_total_credit_attempt += int(c_ele.credit_attempt)
                    if int(c_ele.credit_earn) > 0:
                        # Update course_info to tm_cm_info
                        tm_cm_ele.credit_earn = int(c_ele.credit_earn)
                        # Update the trimester info.
                        tm_total_credit_earn += int(c_ele.credit_earn)
                        #print("**********tm_total_credit_earn:", tm_total_credit_earn)
                        tm_total_point += float(c_ele.course_point) * float(c_ele.credit_earn)
                        #print("**********tm_total_point:", tm_total_point)
                        tm_total_gpa  = tm_total_point/tm_total_credit_earn
                        #print("**********tm_total_gpa :", tm_total_gpa)
                        cm_total_credit_earn += int(c_ele.credit_earn)
                        cm_total_point += float(c_ele.course_point) * float(c_ele.credit_earn)
                        cm_total_gpa  = tm_total_point/tm_total_credit_earn

                    tm_course_num += 1
                    tm_total_course_cnt += 1
                    tm_cm_ele.tm_course_cnt = tm_total_course_cnt
                    # print('read_grade ==> tm_credit_attempt', tm_ele.tm_credit_attempt)
                    tm_cm_ele.tm_point = tm_total_point
                    tm_cm_ele.tm_grade = tm_total_gpa

                    tm_cm_ele.tm_credit_attempt = tm_total_credit_attempt
                    tm_cm_ele.tm_credit_earn = tm_total_credit_earn

                    tm_cm_ele.cm_credit_attempt = cm_total_credit_attempt
                    tm_cm_ele.cm_credit_earn = cm_total_credit_earn
                    tm_cm_ele.cm_point = cm_total_point
                    tm_cm_ele.cm_grade = cm_total_gpa
                    if float(tm_total_credit_earn) > 0.0:
                        tm_total_gpa = float(tm_total_point)/float(tm_total_credit_earn)
                        tm_cm_ele.tm_grade = tm_total_gpa
                    if float(cm_total_credit_earn) > 0.0:
                        cm_total_gpa = float(cm_total_point)/float(cm_total_credit_earn)
                        tm_cm_ele.cm_grade = cm_total_gpa

                    #print("*********tm_total_credit_earn:", tm_total_credit_earn)
                    #print("*********cm_total_credit_earn:", cm_total_credit_earn)
                    #print("*********tm_cm_ele.cm_credit_earn:", tm_cm_ele.cm_credit_earn)
                    tm_cm_info.append(tm_cm_ele)
                    # print('inside: tm_cm_info:', tm_cm_info)
        return tm_cm_info, tm_total_credit_earn, tm_total_gpa, cm_total_credit_earn, cm_total_gpa

    @classmethod
    def calc_print_transfer_credit(cls, transfer_info):
        """
        Calculate Transfer Credit (transfer_info)
        """
        print("Transfer Information:")
        total_transfer_credit = 0
        for t_ele in transfer_info:
            print(f"{'  trimester_year: ' + t_ele.year:<31}{'c_id: ' + t_ele.course_id:<12}\
{'c_title: ' + t_ele.course_title:<30}{' credit earn: ' + str(t_ele.credit_earn):<16}\
{'grade: ' + t_ele.course_grade:<11}")
            if int(t_ele.credit_earn) > 0:
                total_transfer_credit += int(t_ele.credit_earn)
            t_ele.total_transfer_credit = total_transfer_credit
        print('  total transfer credit:', total_transfer_credit)
        print()
        return total_transfer_credit

    @classmethod
    def print_summary (cls, transfer_credit, cm_total_credit_earn, cm_total_gpa):
        """
        print transfer, total cumulative credit, gpa
        """
        print("Transcript Summary:")
        str_transfer_credit = f"{transfer_credit:.2f}"
        str_cm_total_credit = f"{cm_total_credit_earn:.2f}"
        total_credit = int(transfer_credit)+int(cm_total_credit_earn)
        str_total_credit = f"{total_credit:.2f}"
        str_total_gpa = f"{cm_total_gpa:.2f}"
        print(f"{'Total transfer credit: ' + str_transfer_credit:<30}\
{'  Total credit: ' + str_cm_total_credit:<30}\
{'Total cumulative credit: ' + str_total_credit:<35}\
{'Total cumulative GPA: ' + str_total_gpa:<30}")

#if __name__ == "__main__":
#    r_g = ReadGrade()
#    print('r_g.get_dir():', r_g.get_dir())
