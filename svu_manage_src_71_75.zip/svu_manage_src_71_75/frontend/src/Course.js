import React, { useState, useRef, useEffect, useMemo, useCallback } from 'react';
import { render } from 'react-dom';
import { AgGridReact } from 'ag-grid-react'; // the AG Grid React Component
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS

const Course = () => {
  const [error, setError] = useState(null);
  const gridRef = useRef(); // Optional - for accessing Grid's API
  const [data, setData] = useState(); // Set rowData to Array of Objects, one Object per Row
  const [columnDefs, setCoulmnDefs] = useState ([
    {headerName: "Trimester", field: 'trimester', checkboxSelection: true, flex: 5},
    {headerName: "Year", field: 'year', flex: 4},
    {headerName: "Course No", field: 'course_no', flex: 4}, 
    {headerName: "Title", field: 'title', flex: 25},
    {headerName: "Time", field: 'time', flex: 5},
    {headerName: "Create Attempted", field: 'credit_attempted', flex: 4},
    // {headerName: "Course ID", field: 'cid'}
  ]);
  //setColumnDefs(columns);
  // DefaultColDef sets props common to all Columns
  const defaultColDef = useMemo( ()=> ({
      sortable: true,  editable: true, filter: true, floatingFilter: true
    }));

  // Example of consuming Grid Event
  const cellClickedListener = useCallback( event => {
    console.log('cellClicked', event);
  }, []);

  // Example load data from sever
  useEffect(() => {
    fetch('/course')
    .then(res => {
      console.log('course => res: ', res)
      if (!res.ok) {
          throw Error ('Could not fetch the data for resource Course') 
      }
      return res.json();
    })
    .then(data => {
      console.log('course => rowData', data.course);
      setData(data.course);
    })
    .catch (err => { 
      console.log(err.message)
      setError(err.message);
    })
  }, []);

  // Example using Grid's API
  const buttonListener = useCallback( e => {
    gridRef.current.api.deselectAll();
  }, []);

  let gridApi;
  const onGridReady = params => {
    console.log ('Course => onGridReady => params: ' , params)
    gridApi=params.api;
    //console.log ('Course => onGridReady => gridApi: ' , gridApi)
    //gridApiOptions=params.GridOptions;
    //console.log ('Course => onGridReady => gridApiOptions: ' , gridApiOptions)
  }

  const gridOptions = {
    // callback tells the grid to use the 'id' attribute for IDs, IDs should always be strings
    getRowId: params => params.data.id,

    // other grid options ...
  }

  const getAllRows = () => {
    let rowData = [];
    console.log ('Course => onGridReady => gridApi: ' , gridApi)
    // iterate through every node in the grid
    gridOptions.api.forEachNode((rowNode, index) => {
      console.log('node ' + rowNode.data.athlete + ' is in the grid');
    });
    return rowData;
  }

  const onGetDataClick = () => {
    console.log ('Course => onGetDataClick() => gridApi: ' , gridApi)
    //gridApi.exportDataAsCsv();
    let allRowData = [];
    allRowData = getAllRows()
    console.log('Course => allRowData: ', allRowData)
  }
  return (
    <div>
      {/* Example using Grid's API */}
      <button onClick={ buttonListener }>Push Me</button>
      <button onClick={()=>onGetDataClick()}>Get Data</button>
      {/* On div wrapping Grid a) specify theme CSS Class Class and b) sets Grid size */}
      <div className="ag-theme-alpine" style={{width: 1200, height: 750}}>
        <AgGridReact
            ref={ gridRef } // Ref for accessing Grid's API
            rowData={ data } // Row Data for Rows
            columnDefs = { columnDefs } // Column Defs for Columns
            defaultColDef={ defaultColDef } // Default Column Properties
            animateRows={ true } // Optional - set to 'true' to have rows animate when sorted
            rowSelection='multiple' // Options - allows click selection of rows
            onCellClicked={ cellClickedListener } // Optional - registering for Grid Event
            onGridReady= { onGridReady }
            />
      </div>
    </div>
  );
}

export default Course;