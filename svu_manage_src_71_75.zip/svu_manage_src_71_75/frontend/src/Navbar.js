import { Link } from 'react-router-dom';
const title = "SVU Management System";
const Navbar = () => {
    return ( 
        <nav className="navbar">
            <h1>{ title }</h1>
            <div className="links">
                <Link to="/course">Course</Link>
                <Link to="/register">Registration</Link>
                <Link to="/transcript">Transcript</Link>
                <Link to="/transcriptDetails">Transcript Details</Link>
                <Link to="/directory">Directory</Link>
                <Link to="/update">Update</Link>
                <Link to="/login">Login</Link>
                <Link to="/contact">Contact </Link>
            </div>
        </nav> 
    );
}
 
export default Navbar;