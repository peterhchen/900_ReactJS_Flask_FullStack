import { useState, useEffect } from 'react'
import CourseList from './CourseList'

const cList = [
    { 
        "course_no_title": "CE600 Computer Architecture I",
        "trimester": "2015 Fall Trimester", "credit": 3, "id": 1
    },
    {
        "course_no_title": "CS440 Computer Networks I",
        "trimester": "2015 Fall Trimester",
        "credit": 3, "id": 2
    },
    {
        "course_no_title": "CS596-012 SP: XML and Application",
        "trimester": "2015 Fall Trimester",
        "credit": 3,
        "id": 3
    }];

const Transcript = () => {
    const [course, setCourse] = useState(null);
    const [courseList, setCourseList] = useState (cList);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);
    const [courseNoTitle, setCourseNoTitle] = useState(cList[0].course_no_title);

    const handleDelete = (id) => {
        const newCourse = course.filter(course => course.id !== id)
        setCourse (newCourse);
    }

    const handleAdd = (item) => {
        console.log('handleAdd => item', item)
        console.log('handleAdd => ...courses', ...course)
        setCourseList(courses => [...course, item]);
        console.log('handleAdd => courses', course)
    }

    const handleSubmit = (e) => {
        e.preventDefault();  // Keep data/prevent page refreshing to default. 
        const c = { course };
        console.log ('course:', c);
    
        fetch('http://127.0.0.1:5000/transcript/', {
            method: 'POST',
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(course)
        }).then(() => {
            console.log('new course added');
        })
    }

    useEffect(() => {
        //fetch('/transcript')
        // Got data from server.py: @app.route ("/transcript")
        fetch('http://127.0.0.1:5000/transcript')
            .then(res => {
                console.log(res)
                if (!res.ok) {
                    throw Error ('Could not fetch the data for resource transcripts') 
                }
                return res.json();
            })
            .then(data => {
                console.log('transcript => data', data);
                setCourse(data);
                setIsLoading(false);
                setError(false);
            })
            .catch (err => { 
                console.log(err.message)
                setIsLoading(false);
                setError(err.message);
            })
    }, []);
    
    console.log('before render:', course)
    return (
        <div className = "home">
            <h2>Transcript</h2>
            <form onSubmit = { handleSubmit }>
                { error && <div> { error }</div>}
                { isLoading && <div>Loading ...</div>}
                { 
                    (typeof course === 'undefined' || course === null) ? (
                        <p>Loading data...</p>
                    ):(
                        <h5> 
                        { "kw: " + course.kw } <br></br>
                        { " Student ID: " + course.ID } <br></br> 
                        { " Name: " + course.name }<br></br>
                        { " DOB: " + course.DOB }<br></br>
                        </h5>
                    )
                }
                { 
                    (typeof course === 'undefined' || course === null) ? (
                    <p>Loading Transcripts...</p>
                    ):(
                        course.transcript.map((transcript, i) => (
                            <p key = {i} > {" trimseter: " + transcript.a01_trimester}
                                {" year: " + transcript.a02_year}
                                {" course_no: " + transcript.a03_course_no} { " title: " + transcript.a04_title} 
                                {" credit_attempted: " + transcript.a05_credit_attempted}
                                {" credit earned: " + transcript.a06_credit_earned} 
                                {" grade: " + transcript.a07_grade} 
                                {" points: " + transcript.a08_points} 
                                {" cid: " + transcript.tid} </p>
                            )
                        )
                    )
                }

            </form>
        </div>
    );
}
 
export default Transcript;