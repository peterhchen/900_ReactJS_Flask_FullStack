// https://www.youtube.com/watch?v=i8fAO_zyFAM
import Popup_Dialog from './Popup_Dialog';
import { useState } from 'react';

const Popup = () => {
  var flag = true;
  var num = 5;
  var seasons = ["spring", "summer", "fall", "winter"];

  const [buttonPopup, setButtonPopup] = useState (false);

  return (
    <div className="./popup.css">
      <popup>
        <h1>React Popup</h1>
        <br></br>
        { 'flag: ' + flag.toString() } 
        <br></br>
        { 'num: ' + num }
        <br></br>
        {seasons.map ((season) => (
          <li key = {season.id}>{season}</li>
        ))}
        <button onClick={() => setButtonPopup(true)}>Open Popup</button>
        {/* <Popup_Dialog trigger={true}> */}
        <Popup_Dialog trigger={ buttonPopup } setTrigger = {setButtonPopup}> 
          <h3>Popup Dialog</h3>
          <p>This is my button triggered popup</p>
        </Popup_Dialog>
      </popup>

    </div>
  );
}

export default Popup;