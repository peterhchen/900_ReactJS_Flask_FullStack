from flask import Flask
# CORS (Cross Origin Resource Sharing)
# Allow server (flask) to cross any orgins (domain, scheme, or port).
# https://www.youtube.com/watch?v=tPKyDM0qEB8
# > pip install flask-cors
from flask_cors import CORS
from flask import request
app = Flask (__name__)
CORS(app)  # make every URL endpoint allowed cross origin

# API Route
@app.route ("/course")
def create():
    return {
        "course": [
        {
            "id": 0, "trimester": "Fall", "year": 2023, "course_no": "CS450", "title": "Computer Architecture I", 
            "time": "Mon 6-9pm", "credit_attempted": 3
        },
        {
            "id": 1, "trimester": "Fall", "year": 2023, "course_no": "CS440", "title": "Computer Networks I",
            "time": "Tue 6-9pm", "credit_attempted": 3
        },
        {
            "id": 2, "trimester": "Fall", "year": 2023, "course_no": "CS500", "title": "Operating System Design",
            "time": "Wed 6-9pm", "credit_attempted": 3
        },
        {
            "id": 3, "trimester": "Fall", "year": 2023, "course_no": "CS520", "title": "Database System Design",
            "time": "Thu 6-9pm", "credit_attempted": 3
        },
        {
            "id": 4, "trimester": "Fall", "year": 2023, "course_no": "CS540", "title": "Computer Networks II",
            "time": "Fri 6-9pm", "credit_attempted": 3
        },
        {
            "id": 5, "trimester": "Fall", "year": 2023, "course_no": "CS502", "title": "Design and Analysis of Algorithm",
            "time": "Sat 6-9pm", "credit_attempted": 3 
        },
        {
            "id": 6, "trimester": "Fall", "year": 2023, "course_no": "CS596-003", "title": "SP: Data Pipeline: Apache Airflow",
            "time": "Mon 6-9pm", "credit_attempted": 3
        },
        {
            "id": 7, "trimester": "Fall", "year": 2023, "course_no": "CS596-005", "title": "SP: Machine Learning: Scikit-learn",
            "time": "Tue 6-9pm", "credit_attempted": 3
        },
        {
            "id": 8, "trimester": "Fall", "year": 2023, "course_no": "CS596-007", "title": "SP: Deep Learning: PyTorch, Tensoflow, and Keras",
            "time": "Wed 6-9pm", "credit_attempted": 3
        },
        {
            "id": 9, "trimester": "Fall", "year": 2023, "course_no": "CS596-009", "title": "SP: Reinforcement Learning: OpenAI and PyTorch",
            "time": "Thu 6-9pm", "credit_attempted": 3
        },
        {
            "id": 10, "trimester": "Fall", "year": 2023, "course_no": "CS596-011", "title": "SP: Full Stack Development: ReactJS, Python, and Flask",
            "time": "Fri 6-9pm", "credit_attempted": 3
        },
        {
            "id": 11, "trimester": "Fall", "year": 2023, "course_no": "CS596-026", "title": "SP: OpenStack: Build Private Cloud",
            "time": "Sat 6-9pm", "credit_attempted": 3
        },
        {
            "id": 12, "trimester": "Fall", "year": 2023, "course_no": "CS596-027", "title": "SP: Software Defined Networking",
            "time": "Mon 6-9pm", "credit_attempted": 3
        },
        {
            "id": 13, "trimester": "Fall", "year": 2023, "course_no": "CS596-028", "title": "SP: Hadoop and Big Data: Manage Cloud by Kafka, Spark, Flume, Zookeeper, HDFS",
            "time": "Tue 6-9pm", "credit_attempted": 3
        },
        {
            "id": 14, "trimester": "Fall", "year": 2023, "course_no": "CS596-039", "title": "SP: Web Applicaiton Testing: Selenium, Docker, CI/CD",
            "time": "Wed 6-9pm", "credit_attempted": 3
        },
        {   
            "id": 15, "trimester": "Fall", "year": 2023, "course_no": "CS596-041", "title": "SP: High Performace Networks",
            "time": "Thu 6-9pm", "credit_attempted": 3
        }
        ]
    }

# API Route
@app.route ("/transcript")
def transcript():
    return {
        "kw": "1503011365; SOHAN BHARGAV KEESARA; 03-05-1993",
        "ID": "1503011365", 
        "name": "SOHAN BHARGAV KEESARA",
        "DOB": "03-05-1993",
        "transcript": [
        {
            "trimester": "Transfer", "year": 2015, "course_no": "EE220", "title": "RFIC Design I",
            "credit_attempted": "TR", "credit_earned": 3, "grade": "TR", "points": "TR",
            "tid": 1
        },
        {
            "trimester": "Transfer", "year": 2015, "course_no": "EE250", "title": "Prob Ran Vari & St P",
            "credit_attempted": "TR", "credit_earned": 3, "grade": "TR", "points": "TR",
            "tid": 2
        }]
    }

@app.route ("/search", methods=["GET", "POST"])
def search():
    student_ID = request.args.get ('STUDENT_ID')
    fname = request.args.get('FNAME')
    lname = request.args.get('LNAME')
    dob = request.args.get('DOB')
    cmd = request.args.get('CMD')
    print("Flask => STUDENT_ID:", student_ID)
    print("Flask => Name:", fname)
    print("Flask => Name:", lname)
    print("Flask => DOB:", dob)
    print("Flask => CMD:", cmd)
    return {
        "kw": "1503011365; SOHAN BHARGAV KEESARA; 03-05-1993",
        "student_id": "1503011365", 
        "name": "SOHAN BHARGAV KEESARA",
        "DOB": "03-05-1993",
        "transcript": [
        {
            "trimester": "Transfer", "year": 2015, "course_no": "EE220", "title": "RFIC Design I",
            "credit_attempted": "TR", "credit_earned": 3, "grade": "TR", "points": "TR"
        },
        {
            "trimester": "Transfer", "year": 2015, "course_no": "EE250", "title": "Prob Ran Vari & St P",
            "credit_attempted": "TR", "credit_earned": 3, "grade": "TR", "points": "TR"
        }]
    }

@app.route ("/rowdataex", methods=["GET", "POST"])
def url_param_rowdata():
    student_ID = request.args.get ('STUDENT_ID')
    name = request.args.get('Name')
    dob = request.args.get('DOB')
    print("Flask => STUDENT_ID:", student_ID)
    print("Flask => Name:", name)
    print("Flask => DOB:", dob)
    return {"STUDENT_ID": student_ID, "Name": name, "DOB": dob }
    
if __name__ == "__main__":
    app.run(debug = True)