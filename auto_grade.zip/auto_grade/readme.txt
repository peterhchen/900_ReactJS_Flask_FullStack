1. reg_trans: register and transcript
   2015, 2015, 2017, ...
     1.1. register.xlsx: 
        1.1.1 register information 
        1.1.2 sepcify path for course_grade 
     1.2. transcript.xlsx: final transcript
2. To run the auto_grade
 > cd code
 > ./run_auto_grade.scr
