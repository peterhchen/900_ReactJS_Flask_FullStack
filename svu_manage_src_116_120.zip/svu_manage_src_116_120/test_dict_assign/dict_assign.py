json_data = {}
json_data['kw'] = "Jonathan; 11-02-2000;"
course_list = [{"cs1": "computer architecture"}, {"cs2": "computer network"}]
json_data['course'] = []
print('json_data["course"]: ', json_data["course"])
for ele in course_list: 
    json_data['course'].append(ele) 

print('json_data: ', json_data)