// rfce (React Functional Compoent Export)
import React from 'react'
import './index.css'

function SearchPopup (props) {
    console.log ('props.children: ', props.children)
    return (props.trigger) ? (
            <div className='searchPopup'>
            <div className="searchPopup-inner">
                <button className='close-btn'>Close</button>
                <button className='ok-btn'>OK</button>
                { props.children 
                }
            </div>
            </div>
    ): "";
}

export default SearchPopup;