const Registration = () => {
    const handleCreate = () => {
        console.log('handle Create' );
    }
    const handleFind = (param, e) => {
        console.log('handle ' + param, e.target);
    }
    const handleSave = (param, e) => {
        console.log('handle ' + param, e.target);
    }
    const handleDel = (param, e) => {
        console.log('handle ' + param, e.target);
    }
    return (
        <div className = "home">
            <h2>Registration Page</h2>
            <button onClick={ handleCreate }>Create</button>
            <button onClick={(e) => handleFind ('Find', e)}>Find</button>
            <button onClick={(e) => handleSave ('Save', e)}>Save</button>
            <button onClick={(e) => handleDel ('Delete', e)}>Delete</button>
        </div>
    );
}
 
export default Registration;