//import { Link } from 'react-router-dom';

const CourseList = ({ courses, title, handleDelete }) => {
    return (  
        <div className="course-list">
            <h2> { title } </h2>
            {courses.map((course) => (
                <div className="course-preview" key = {course.id} >
                    {/* <Link to = {`/courses/${course.id}`}> */}
                        <p>{course.page} &emsp; {course.trimester} &emsp; {course.course_no} &emsp; {course.title} &emsp; 
                        { course.credit_attempted } &emsp; {course.credit_earned} &emsp; 
                        {course.grade } &emsp; {course.points }</p>
                        <button onClick = {() => handleDelete (course.id)} > delete course</button>
                    {/* </Link> */}
                </div>
            ))}
        </div>
    );
}
 
export default CourseList;