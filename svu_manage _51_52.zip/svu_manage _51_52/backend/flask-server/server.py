from flask import Flask
from flask import request
app = Flask (__name__)

# API Route
@app.route ("/transcripts")
def transcripts():
    return {
        "kw": "1503011365; SOHAN BHARGAV KEESARA; 03-05-1993",
        "ID": "1503011365", 
        "name": "SOHAN BHARGAV KEESARA",
        "DOB": "03-05-1993",
        "transcripts": [
        {
            "trimester": "2015 Transfer", "course_no": "EE220", "title": "RFIC Design I",
            "credit_attempted": "TR", "credit_earned": 3, "grade": "TR", "points": "TR",
            "tid": 1
        },
        {
            "trimester": "2015 Transfer", "course_no": "EE250", "title": "Prob Ran Vari & St P",
            "credit_attempted": "TR", "credit_earned": 3, "grade": "TR", "points": "TR",
            "tid": 2
        }]
    }

@app.route ("/search", methods=["GET", "POST"])
def url_param():
    student_ID = request.args.get ('STUDENT_ID')
    name = request.args.get('Name')
    dob = request.args.get('DOB')
    return {"STUDENT_ID": student_ID, "Name": name, "DOB": dob }
    
if __name__ == "__main__":
    app.run(debug = True)