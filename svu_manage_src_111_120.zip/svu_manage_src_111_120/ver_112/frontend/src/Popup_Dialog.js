import React from 'react'
import './popup_Dialog.css'

const Popup_Dialog = ((props) => {
    console.log ('props.trigger:', props.trigger)
    return (props.trigger) ? (
        <div className="popup">
            <div className="popup-inner">
                <button className="close-btn" onClick = { () => props.setTrigger(false)} >close</button>
                { props.children }
            </div>
        </div>
    ): "";
})

export default Popup_Dialog