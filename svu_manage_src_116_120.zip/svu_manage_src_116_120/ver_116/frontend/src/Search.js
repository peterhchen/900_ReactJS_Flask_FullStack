import './App.css';
import React, { useState, useRef, useEffect, useMemo, useCallback } from 'react';
//import { useForm } from "react-hook-form";
import { AgGridReact } from 'ag-grid-react'; // the AG Grid React Component
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS
import Popup_Dialog from './Popup_Dialog';
import SearchPopup from './SearchPopup';
import createOneSearchRecord from './searchFactory';
let rowData = [];
const getRowData = () => {
    //let rowData = [];
    //gridRef.current.api.forEachNode (node => rowData.push(node.data));
    console.log ('getRowData => rowData:', rowData)
    return rowData;
}

const http_str = "http://127.0.0.1:5000";

const Search = () => {
  let studentArr = [];
  let studentArrFound = 0
  const [studentSel, setStudentSel] = useState('')
  const [studentArr1Found, setStudentArr1Found] = useState(0)
  const [studentArr1, setStudentArr1] = useState(0)
  const [selVal, setSelVal] = useState('')
  const [onSaveFlag, setOnSaveFlag] = useState(false)
  const [input, setInput] = useState("");
  const [studentIDSend, setStudentIDSend] = useState(false);
  // Set initial values of Form.
  const [firstName, setFirstName] = useState("SOHAN");
  const [lastName, setLastName] = useState("KEESARA");
  const [dob, setDob] = useState("03-05-1993");
  const [studentID, setStudentID] = useState("2303011365");
  const gridRef = useRef(); // Optional - for accessing Grid's API
  const [rowData, setRowData] = useState(); // Set rowData to Array of Objects, one Object per Row
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [columnDefs, setCoulmnDefs] = useState ([
    {headerName: "ID", field: 'id', sortable: true, checkboxSelection: true, headerCheckboxSelection: true, flex: 5},
    {headerName: "Trimester", field: 'trimester', flex: 7},
    {headerName: "Year", field: 'year', flex: 5},
    {headerName: "Course No", field: 'course_no', flex: 7}, 
    {headerName: "Course Title", field: 'title', flex: 25},
    //{headerName: "Time", field: 'time', flex: 7},
    {headerName: "Credit Attempted", field: 'credit_attempted', flex: 9},
    {headerName: "Credit Earned", field: 'credit_earned', flex: 8},
    {headerName: "Grade", field: 'grade', flex: 5},
    {headerName: "Points", field: 'points', flex: 5}
  ]);
  
  const defaultColDef = useMemo( ()=> ({
      sortable: true,  
      editable: true, 
      filter: true, 
      floatingFilter: true
    }), []);

  
  const onGridReady = (params) => {
      console.log("grid is ready")
      setRowData(rowData);
  }

  //define selection type single or multiple
  const rowSelectionType='multiple'
  const onSelectionChanged = (event) => {
    console.log('onRowSelectionChanged => event: ', event)
    console.log('onRowSelectionChanged => event.api.getSelectedRows(): ', 
    event.api.getSelectedRows())
  }

  const getRowData = () => {
    let rowData = [];
    gridRef.current.api.forEachNode (node => rowData.push(node.data));
    return rowData; 
  }

  const fetchFunction = (http_str, firstName, lastName, dob, student_id) => {
    //fetch('http://127.0.0.1:5000/search?' + new URLSearchParams({
      fetch(http_str + '/search?' + new URLSearchParams({
        //FNAME: 'SOHAN',
        FNAME: firstName,
        //LNAME: 'KEESARA',
        LNAME: lastName,
        //DOB: '03-05-1993',
        DOB: dob, 
        //STUDENT_ID:'1503011365',
        STUDENT_ID: student_id,
        CMD: 'get'
      }))
      .then(res => {
          console.log('onStart => search => res:', res)
          if (!res.ok) {
              throw Error ('Could not fetch the data for resource transcripts') 
          }
          return res.json();
      })
      .then(data => {
          console.log('onStart => search => data:', data);
          studentArrFound = 0;
          if (data.length > 1) {
            setRowData(null);
            studentArr = [];
            //studentArr.push("More than one student found. Please use Studen ID to search.")
            for (var i = 0; data && i < data.length; i++) {
              studentArr.push(data[i].kw)
            }
            studentArrFound = 1
            console.log('studentArrFound:', studentArrFound)
  
            console.log('studentArr:', studentArr)
            setStudentArr1Found(1)
            console.log('studentArr1Found:', studentArr1Found)
            setStudentArr1(studentArr)
            console.log('studentArr1:', studentArr1)
          } else if (data.length <= 1 || (rowData || data === 'undefined')) {
            setRowData(data); // one dimension array
            console.log('row Data:', rowData)
          } else {
            setRowData(data); // one dimension array
          }
          setIsLoading(false);
          setError(false);
          if (rowData)
            console.log ('onStart => search => rowData:', rowData)
          else
            console.log ('rowData not found:', rowData)
          if (studentArrFound) {
            console.log ('onStart => search => studentArrFound:', studentArrFound)
            console.log ('onStart => search => studentArr:', studentArr)
          } else {
            console.log ('studenArrFound not found:', studentArrFound)
            console.log ('onStart => search => studentArr:', studentArr)
          }
      })
      .catch (err => { 
          console.log('onStart => search => err.message:',err.message)
          setIsLoading(false);
          setError(err.message);
      })
  }

  const onStart = useCallback( (firstName, lastName, dob, student_id) => {
    //setFirstName (firstName);
    //setLastName (lastName);
    //setDob (dob);
    //setStudentID (studentID);
    console.log('onStart => firstName:', firstName)
    console.log('onStart => lastName:', lastName)
    console.log('onStart => dob:', dob)
    console.log('onStart => studentID:', student_id)
    let newdata = [];
    fetchFunction (http_str, firstName, lastName, dob, student_id);
  }, []);

  const sendStudentID = () => {
    setStudentIDSend(true);
    setTimeout(() => {
      setOnSaveFlag(false);
    }, 2000);
  };

  const onSave = useCallback ( () => {
    const newRecord = getRowData();
    const res = gridRef.current.api.applyTransaction({
      add: [newRecord],
      update: [],
      remove: []
    });
    console.log ('onSave() => res:', res)
    setOnSaveFlag(true)
    console.log ('onSave() => onSaveFlag:', onSaveFlag)
  }, []);

  const getRowId = useCallback( params => {
    //console.log ('getRowId => params.data.id:', params.data.id)
    return params.data.id;
  }, []);

  const handleStudentSel = (event) => {
    let kw_str = event.target.value;
    console.log ('kw_str:', kw_str) // kw_str: 2303010003; Jonathan J. Chen ; 10-30-2000
    let studentID = kw_str.split('; ')[0] 
    console.log ('studentID:', studentID) // studentID: 2303010003
    fetchFunction (http_str, '', '', '', studentID);
    setSelVal (studentID)
  }

  return (
    <div>
      <div className="search">
        <h2>Search</h2>
        <hr></hr>
          <label>First Name: </label>
          <input 
            type="text" 
            required
            value = { firstName }
            onChange = {(e) => setFirstName(e.target.value)}
          />
          <label>Last Name: </label>
          <input 
            type="text"
            required
            value = { lastName }
            onChange = {(e) => setLastName (e.target.value)}
          />
          <label>Date of Birth: </label>
          <input 
            type="text"
            required
            value = { dob }
            onChange = { (e) => setDob (e.target.value)}
          />
          <label>Student ID: </label>
          <input 
            type="text" 
            value = { studentID }
            onChange = { (e) => setStudentID(e.target.value) }
          />
          <button onClick={ () => onStart (firstName, lastName, dob, studentID) }>Start</button>
          <button onClick={ getRowData }>Get RowData</button>
          <button onClick={ onSave }>Save</button>
      </div>
      <hr></hr>
      <p>
        {
          "studentArrFound: " + studentArrFound
        }
      </p>
      <p>
        {
          "studentArr1Found: " + studentArr1Found
        }
      </p>
      <p>
        {
          "studentArr1: " + studentArr1
        }
      </p>
      <div className="ag-theme-alpine" style={{width: 1500, height: 750}}>
        { error && <div> { error }</div>}
        { isLoading && <div>Loading ...</div>}
        { 
          (studentArr1 && studentArr1Found === 1) ? (
            <div>
              {/* <select value={studentSel} onChange={(e) => { setStudentSel (e.target.value)} }> */}
              <select value={ selVal } onChange={(e) => { handleStudentSel (e)} }>
                <option>-- Select a Student --</option>
                {/* When we use map, we need a key for react: "opt.student_id" give us a "required key warning": */}
                {
                   studentArr1.map((opt) => <option key={ opt } value= {opt} > {opt} </option>)
                }
              </select>
              <br></br>
              <p>Selected Student: { selVal }</p>
            </div>
          ) : ""
        }
        {
          <div><br /></div>
        }
        {
          (typeof rowData === 'undefined' || rowData === null) ? (
              <p>Transcript information not found</p>
          ):(
            (onSaveFlag == false) ? (
              <AgGridReact
                ref={ gridRef } // Ref for accessing Grid's API
                asyncTransactionWaitMillis={5000}
                //enableCellChangeFlash = {true}
                getRowId={ getRowId }
                rowData={ rowData.course } // Row Data for Rows
                columnDefs = { columnDefs } // Column Defs for Columns
                defaultColDef={ defaultColDef } // Default Column Properties
                onGridReady={ onGridReady }
                rowSelection={ rowSelectionType } 
                onSelectionChanged={ onSelectionChanged }
                rowMultiSelectWithClick={ true } 
                animateRows={ true } // Optional - set to 'true' to have rows animate when sorted
                //rowSelection='multiple' // Options - allows click selection of rows
              />
            ): (
              <div>
                <div className="modal-input-label">
                  <label className="modal--input-text ">Student ID: </label>
                  <input
                    placeholder={selVal}
                    className="modal-input"
                    label={"Input"}
                    type="transcript"
                    onChange={(input) => setInput(input)}
                  />
                </div>
                <div>
                  <button
                    className="modal-footer-button modal-button-send"
                    onClick={sendStudentID}
                  >
                    Send
                  </button>
                  <button
                    className="modal-footer-button modal-button-cancel"
                    onClick={() => {
                      //setOpenModal(false);
                      setOnSaveFlag(false);
                    }}
                  >
                    Cancel
                  </button>
                  </div>
              </div>
            )
          )
        }
      </div>
    </div>
  );
}

export default Search;