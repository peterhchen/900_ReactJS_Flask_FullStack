import Navbar from './Navbar';
import Transcript from './Transcript';
import Register from './Register';
import TranscriptDetails from './TranscriptDetails';
import { useState, useEffect } from 'react';

import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';

function App() {
  const [data, setData] = useState ([{}])
  useEffect(() => {
    //fetch('http://127.0.0.1:5000/transcripts').then(
    fetch('/transcripts').then(
      response => response.json()
      ).then(
        data => {
          setData(data)
          console.log('App => data:', data)
        }
      )
  }, [])

  return (
    <div className="App">
      <Router>
        <Navbar />
        <div className="content">
          { (typeof data === 'undefined') ? (
              <p>Loading data...</p>
            ):(
             <h5> 
              { "kw: " + data.kw } <br></br>
              { " Student ID: " + data.ID } <br></br> 
              {" Name: " + data.name }<br></br>
              {" DOB: " + data.DOB }<br></br>
            </h5>
            )
          }
          { (typeof data.transcripts === 'undefined') ? (
              <p>Loading Transcripts...</p>
            ):(
                data.transcripts.map((transcript, i) => (
                  <p key = {i} > {" trimseter: " + transcript.trimester}  
                    {" course_no: " + transcript.course_no} { " title: " + transcript.title} 
                    {" credit_attempted: " + transcript.credit_attempted}
                    {" credit earned: " + transcript.credit_earned} 
                    {" grade: " + transcript.grade} 
                    {"points: " + transcript.points} 
                    {" cid: " + transcript.tid} </p>
                )
              )          
          )}
          {/*
            <Routes>
            <Route path ="/" element={ <Register /> } />
              <Route path ="/register" element={ <Register /> } />
              <Route exact path ="/transcript" element={ <Transcript /> } />
              <Route path ="/transcriptDetails/" element={ <TranscriptDetails /> } />
              <Route path ="/transcriptDetails/:id" element={ <TranscriptDetails /> } />
            </Routes>
          */}
        </div>
      </Router>
    </div>

  );
}

export default App;
