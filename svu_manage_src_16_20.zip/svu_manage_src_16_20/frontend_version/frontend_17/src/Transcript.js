import { useState, useEffect } from 'react'
import CourseList from './CourseList'
const Transcript = () => {
    const [courses, setCourses] = useState(null);

    const [name, setName] = useState('Simon')
    const handleDelete = (id) => {
        const newCourses = courses.filter(course => course.id !== id)
        setCourses (newCourses);
    }

    // useFeect() is the function every time we re-render.
    useEffect(() => {
        fetch('http://localhost:8000/courses')
        .then(res => {
            return res.json();
        })
        .then(data => {
            console.log(data);
            setCourses(data);
        })
    }, []);

    return (

        <div className = "home">
            {courses && <CourseList courses = { courses } title = {"SVU courses"} handleDelete = {handleDelete} />}
            <button onClick = {() => setName('Jerry')}>Change Name</button>
            <p>{ name }</p>
        </div>

    );
}
 
export default Transcript;